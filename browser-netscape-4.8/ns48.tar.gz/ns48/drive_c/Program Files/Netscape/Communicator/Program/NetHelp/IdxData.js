topicCount = 184
var indexCount = 342

var indexValue = new Array (342)
var indexStartIndices = new Array (342)
var indexStopIndices = new Array (342)

var linkNames = new Array (878)
var topicIndices = new Array (878)

var topicStrings = new Array (184)

indexValue[ 0 ] = "404 access denied"
indexStartIndices[ 0 ] = 0
indexStopIndices[ 0 ] = 0
linkNames[ 0 ] = "nethelp:netscape/Trouble:access_denied"
topicIndices[ 0 ] = 90

indexValue[ 1 ] = "access, security"
indexStartIndices[ 1 ] = 1
indexStopIndices[ 1 ] = 2
linkNames[ 1 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_APPLET"
topicIndices[ 1 ] = 132
linkNames[ 2 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 2 ] = 67

indexValue[ 2 ] = "account information"
indexStartIndices[ 2 ] = 3
indexStopIndices[ 2 ] = 3
linkNames[ 3 ] = "nethelp:netscape/Trouble:trouble_usr_passwd"
topicIndices[ 3 ] = 43

indexValue[ 3 ] = "adding newsgroups"
indexStartIndices[ 3 ] = 4
indexStopIndices[ 3 ] = 4
linkNames[ 4 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 4 ] = 7

indexValue[ 4 ] = "add-ons"
indexStartIndices[ 4 ] = 5
indexStopIndices[ 4 ] = 5
linkNames[ 5 ] = "nethelp:netscape/Composer:COMPOSER_PLUGINS"
topicIndices[ 5 ] = 144

indexValue[ 5 ] = "address books"
indexStartIndices[ 5 ] = 6
indexStopIndices[ 5 ] = 16
linkNames[ 6 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 6 ] = 44
linkNames[ 7 ] = "nethelp:netscape/Messengr:CREATE_ADD_BOOK"
topicIndices[ 7 ] = 149
linkNames[ 8 ] = "nethelp:netscape/Messengr:ADD_USER_CONTACT"
topicIndices[ 8 ] = 122
linkNames[ 9 ] = "nethelp:netscape/Messengr:ADD_LIST_MAILING_LIST"
topicIndices[ 9 ] = 111
linkNames[ 10 ] = "nethelp:netscape/Messengr:SEARCH_ADDRESS_BOOK"
topicIndices[ 10 ] = 165
linkNames[ 11 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 11 ] = 18
linkNames[ 12 ] = "nethelp:netscape/Messengr:SELECT_ADDRESSES"
topicIndices[ 12 ] = 178
linkNames[ 13 ] = "nethelp:netscape/Messengr:import_address_book"
topicIndices[ 13 ] = 175
linkNames[ 14 ] = "nethelp:netscape/Messengr:export_address_book"
topicIndices[ 14 ] = 180
linkNames[ 15 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_ADDRESSING"
topicIndices[ 15 ] = 152
linkNames[ 16 ] = "nethelp:netscape/Trouble:address_book"
topicIndices[ 16 ] = 92

indexValue[ 6 ] = "address cards"
indexStartIndices[ 6 ] = 17
indexStopIndices[ 6 ] = 20
linkNames[ 17 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 17 ] = 60
linkNames[ 18 ] = "nethelp:netscape/Messengr:ADD_USER_CONTACT"
topicIndices[ 18 ] = 122
linkNames[ 19 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 19 ] = 42
linkNames[ 20 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_FORMATTING"
topicIndices[ 20 ] = 123

indexValue[ 7 ] = "addresses"
indexStartIndices[ 7 ] = 21
indexStopIndices[ 7 ] = 24
linkNames[ 21 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 21 ] = 23
linkNames[ 22 ] = "nethelp:netscape/Messengr:export_address_book"
topicIndices[ 22 ] = 180
linkNames[ 23 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 23 ] = 31
linkNames[ 24 ] = "nethelp:netscape/Trouble:trouble_common_clearloc"
topicIndices[ 24 ] = 38

indexValue[ 8 ] = "addressing"
indexStartIndices[ 8 ] = 25
indexStopIndices[ 8 ] = 25
linkNames[ 25 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_ADDRESSING"
topicIndices[ 25 ] = 152

indexValue[ 9 ] = "addressing messages"
indexStartIndices[ 9 ] = 26
indexStopIndices[ 9 ] = 27
linkNames[ 26 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 26 ] = 44
linkNames[ 27 ] = "nethelp:netscape/Trouble:trouble_email_noshow"
topicIndices[ 27 ] = 45

indexValue[ 10 ] = "AIM"
indexStartIndices[ 10 ] = 28
indexStopIndices[ 10 ] = 28
linkNames[ 28 ] = "nethelp:netscape/Trouble:trouble_common_AIM"
topicIndices[ 28 ] = 128

indexValue[ 11 ] = "alerts"
indexStartIndices[ 11 ] = 29
indexStopIndices[ 11 ] = 29
linkNames[ 29 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 29 ] = 72

indexValue[ 12 ] = "alias"
indexStartIndices[ 12 ] = 30
indexStopIndices[ 12 ] = 30
linkNames[ 30 ] = "nethelp:netscape/Messengr:ADD_LIST_MAILING_LIST"
topicIndices[ 30 ] = 111

indexValue[ 13 ] = "alignment"
indexStartIndices[ 13 ] = 31
indexStopIndices[ 13 ] = 34
linkNames[ 31 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 31 ] = 23
linkNames[ 32 ] = "nethelp:netscape/Composer:Setting_table_properties"
topicIndices[ 32 ] = 102
linkNames[ 33 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 33 ] = 103
linkNames[ 34 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 34 ] = 56

indexValue[ 14 ] = "anchors"
indexStartIndices[ 14 ] = 35
indexStopIndices[ 14 ] = 35
linkNames[ 35 ] = "nethelp:netscape/Composer:PROPERTIES_TARGET"
topicIndices[ 35 ] = 70

indexValue[ 15 ] = "AOL Instant Messenger"
indexStartIndices[ 15 ] = 36
indexStopIndices[ 15 ] = 36
linkNames[ 36 ] = "nethelp:netscape/Trouble:trouble_common_AIM"
topicIndices[ 36 ] = 128

indexValue[ 16 ] = "applets"
indexStartIndices[ 16 ] = 37
indexStopIndices[ 16 ] = 38
linkNames[ 37 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_APPLET"
topicIndices[ 37 ] = 132
linkNames[ 38 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 38 ] = 67

indexValue[ 17 ] = "applications"
indexStartIndices[ 17 ] = 39
indexStopIndices[ 17 ] = 39
linkNames[ 39 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 39 ] = 3

indexValue[ 18 ] = "Ask Me mode"
indexStartIndices[ 18 ] = 40
indexStopIndices[ 18 ] = 40
linkNames[ 40 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 40 ] = 101

indexValue[ 19 ] = "attachments"
indexStartIndices[ 19 ] = 41
indexStopIndices[ 19 ] = 45
linkNames[ 41 ] = "nethelp:netscape/Messengr:attaching_file"
topicIndices[ 41 ] = 47
linkNames[ 42 ] = "nethelp:netscape/Messengr:attaching_file"
topicIndices[ 42 ] = 47
linkNames[ 43 ] = "nethelp:netscape/Messengr:viewing_attachments"
topicIndices[ 43 ] = 48
linkNames[ 44 ] = "nethelp:netscape/Messengr:saving_attachment"
topicIndices[ 44 ] = 49
linkNames[ 45 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MESSAGES"
topicIndices[ 45 ] = 50

indexValue[ 20 ] = "autocompletion"
indexStartIndices[ 20 ] = 46
indexStopIndices[ 20 ] = 46
linkNames[ 46 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 46 ] = 44

indexValue[ 21 ] = "Back button"
indexStartIndices[ 21 ] = 47
indexStopIndices[ 21 ] = 48
linkNames[ 47 ] = "nethelp:netscape/Navigatr:nav_histsearch"
topicIndices[ 47 ] = 168
linkNames[ 48 ] = "nethelp:netscape/Trouble:trouble_stuck"
topicIndices[ 48 ] = 41

indexValue[ 22 ] = "background"
indexStartIndices[ 22 ] = 49
indexStopIndices[ 22 ] = 51
linkNames[ 49 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 49 ] = 103
linkNames[ 50 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_APPEARANCE"
topicIndices[ 50 ] = 124
linkNames[ 51 ] = "nethelp:netscape/Navigatr:nav_color"
topicIndices[ 51 ] = 10

indexValue[ 23 ] = "bcc"
indexStartIndices[ 23 ] = 52
indexStopIndices[ 23 ] = 54
linkNames[ 52 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 52 ] = 44
linkNames[ 53 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 53 ] = 6
linkNames[ 54 ] = "nethelp:netscape/Trouble:trouble_email_noshow"
topicIndices[ 54 ] = 45

indexValue[ 24 ] = "blind carbon copies"
indexStartIndices[ 24 ] = 55
indexStopIndices[ 24 ] = 55
linkNames[ 55 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 55 ] = 6

indexValue[ 25 ] = "blocking websites"
indexStartIndices[ 25 ] = 56
indexStopIndices[ 25 ] = 56
linkNames[ 56 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 56 ] = 133

indexValue[ 26 ] = "bookmarks"
indexStartIndices[ 26 ] = 57
indexStopIndices[ 26 ] = 64
linkNames[ 57 ] = "nethelp:netscape/Navigatr:nav_bcreate"
topicIndices[ 57 ] = 33
linkNames[ 58 ] = "nethelp:netscape/Navigatr:nav_bshort"
topicIndices[ 58 ] = 34
linkNames[ 59 ] = "nethelp:netscape/Navigatr:nav_borg"
topicIndices[ 59 ] = 174
linkNames[ 60 ] = "nethelp:netscape/Navigatr:nav_bsearch"
topicIndices[ 60 ] = 35
linkNames[ 61 ] = "nethelp:netscape/Navigatr:nav_bmulti"
topicIndices[ 61 ] = 176
linkNames[ 62 ] = "nethelp:netscape/Navigatr:nav_bfresh"
topicIndices[ 62 ] = 36
linkNames[ 63 ] = "nethelp:netscape/Navigatr:nav_tool"
topicIndices[ 63 ] = 8
linkNames[ 64 ] = "nethelp:netscape/Trouble:trouble_common_alpha"
topicIndices[ 64 ] = 177

indexValue[ 27 ] = "borders"
indexStartIndices[ 27 ] = 65
indexStopIndices[ 27 ] = 66
linkNames[ 65 ] = "nethelp:netscape/Composer:Setting_table_properties"
topicIndices[ 65 ] = 102
linkNames[ 66 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 66 ] = 103

indexValue[ 28 ] = "browsing"
indexStartIndices[ 28 ] = 67
indexStopIndices[ 28 ] = 72
linkNames[ 67 ] = "nethelp:netscape/Composer:browse_new_page"
topicIndices[ 67 ] = 78
linkNames[ 68 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 68 ] = 61
linkNames[ 69 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 69 ] = 31
linkNames[ 70 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 70 ] = 32
linkNames[ 71 ] = "nethelp:netscape/News:off_work"
topicIndices[ 71 ] = 106
linkNames[ 72 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 72 ] = 101

indexValue[ 29 ] = "bullets"
indexStartIndices[ 29 ] = 73
indexStopIndices[ 29 ] = 73
linkNames[ 73 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 73 ] = 23

indexValue[ 30 ] = "buttons"
indexStartIndices[ 30 ] = 74
indexStopIndices[ 30 ] = 74
linkNames[ 74 ] = "nethelp:netscape/Navigatr:nav_tool"
topicIndices[ 74 ] = 8

indexValue[ 31 ] = "cache settings"
indexStartIndices[ 31 ] = 75
indexStopIndices[ 31 ] = 76
linkNames[ 75 ] = "nethelp:netscape/Navigatr:nav_cache"
topicIndices[ 75 ] = 68
linkNames[ 76 ] = "nethelp:netscape/Trouble:trouble_cache"
topicIndices[ 76 ] = 69

indexValue[ 32 ] = "can't read newsgroups error"
indexStartIndices[ 32 ] = 77
indexStopIndices[ 32 ] = 77
linkNames[ 77 ] = "nethelp:netscape/Trouble:no_news"
topicIndices[ 77 ] = 91

indexValue[ 33 ] = "canceling subscriptions"
indexStartIndices[ 33 ] = 78
indexStopIndices[ 33 ] = 78
linkNames[ 78 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 78 ] = 109

indexValue[ 34 ] = "cc"
indexStartIndices[ 34 ] = 79
indexStopIndices[ 34 ] = 79
linkNames[ 79 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 79 ] = 44

indexValue[ 35 ] = "cells, table"
indexStartIndices[ 35 ] = 80
indexStopIndices[ 35 ] = 81
linkNames[ 80 ] = "nethelp:netscape/Composer:addtable"
topicIndices[ 80 ] = 171
linkNames[ 81 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 81 ] = 103

indexValue[ 36 ] = "certificates"
indexStartIndices[ 36 ] = 82
indexStopIndices[ 36 ] = 82
linkNames[ 82 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_ISSUERS"
topicIndices[ 82 ] = 119

indexValue[ 37 ] = "characters"
indexStartIndices[ 37 ] = 83
indexStopIndices[ 37 ] = 86
linkNames[ 83 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 83 ] = 23
linkNames[ 84 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 84 ] = 24
linkNames[ 85 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 85 ] = 72
linkNames[ 86 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 86 ] = 155

indexValue[ 38 ] = "charts"
indexStartIndices[ 38 ] = 87
indexStopIndices[ 38 ] = 88
linkNames[ 87 ] = "nethelp:netscape/Composer:Inserting_a_table"
topicIndices[ 87 ] = 126
linkNames[ 88 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 88 ] = 103

indexValue[ 39 ] = "cleaning up mail"
indexStartIndices[ 39 ] = 89
indexStopIndices[ 39 ] = 90
linkNames[ 89 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 89 ] = 0
linkNames[ 90 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 90 ] = 51

indexValue[ 40 ] = "colors"
indexStartIndices[ 40 ] = 91
indexStopIndices[ 40 ] = 96
linkNames[ 91 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 91 ] = 24
linkNames[ 92 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 92 ] = 103
linkNames[ 93 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_GENERAL"
topicIndices[ 93 ] = 129
linkNames[ 94 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_APPEARANCE"
topicIndices[ 94 ] = 124
linkNames[ 95 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 95 ] = 72
linkNames[ 96 ] = "nethelp:netscape/Navigatr:nav_color"
topicIndices[ 96 ] = 10

indexValue[ 41 ] = "columns, table"
indexStartIndices[ 41 ] = 97
indexStopIndices[ 41 ] = 98
linkNames[ 97 ] = "nethelp:netscape/Composer:addtable"
topicIndices[ 97 ] = 171
linkNames[ 98 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 98 ] = 103

indexValue[ 42 ] = "command could not be completed"
indexStartIndices[ 42 ] = 99
indexStopIndices[ 42 ] = 99
linkNames[ 99 ] = "nethelp:netscape/Trouble:address_book"
topicIndices[ 99 ] = 92

indexValue[ 43 ] = "component bar"
indexStartIndices[ 43 ] = 100
indexStopIndices[ 43 ] = 100
linkNames[ 100 ] = "nethelp:netscape/Navigatr:nav_compbar"
topicIndices[ 100 ] = 9

indexValue[ 44 ] = "composing"
indexStartIndices[ 44 ] = 101
indexStopIndices[ 44 ] = 103
linkNames[ 101 ] = "nethelp:netscape/Messengr:NEW_MESSAGE_WINDOW"
topicIndices[ 101 ] = 150
linkNames[ 102 ] = "nethelp:netscape/Messengr:saving_message_draft"
topicIndices[ 102 ] = 79
linkNames[ 103 ] = "nethelp:netscape/Messengr:mail_template"
topicIndices[ 103 ] = 151

indexValue[ 45 ] = "confirming delivery"
indexStartIndices[ 45 ] = 104
indexStopIndices[ 45 ] = 104
linkNames[ 104 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 104 ] = 83

indexValue[ 46 ] = "connection problems"
indexStartIndices[ 46 ] = 105
indexStopIndices[ 46 ] = 105
linkNames[ 105 ] = "nethelp:netscape/Trouble:trouble_dialup_messg"
topicIndices[ 105 ] = 17

indexValue[ 47 ] = "connection reset error"
indexStartIndices[ 47 ] = 106
indexStopIndices[ 47 ] = 106
linkNames[ 106 ] = "nethelp:netscape/Trouble:peer_reset"
topicIndices[ 106 ] = 87

indexValue[ 48 ] = "contact lists"
indexStartIndices[ 48 ] = 107
indexStopIndices[ 48 ] = 113
linkNames[ 107 ] = "nethelp:netscape/Messengr:CREATE_ADD_BOOK"
topicIndices[ 107 ] = 149
linkNames[ 108 ] = "nethelp:netscape/Messengr:ADD_USER_CONTACT"
topicIndices[ 108 ] = 122
linkNames[ 109 ] = "nethelp:netscape/Messengr:ADD_LIST_MAILING_LIST"
topicIndices[ 109 ] = 111
linkNames[ 110 ] = "nethelp:netscape/Messengr:SEARCH_ADDRESS_BOOK"
topicIndices[ 110 ] = 165
linkNames[ 111 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 111 ] = 18
linkNames[ 112 ] = "nethelp:netscape/Messengr:import_address_book"
topicIndices[ 112 ] = 175
linkNames[ 113 ] = "nethelp:netscape/Messengr:export_address_book"
topicIndices[ 113 ] = 180

indexValue[ 49 ] = "converting images"
indexStartIndices[ 49 ] = 114
indexStopIndices[ 49 ] = 114
linkNames[ 114 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 114 ] = 95

indexValue[ 50 ] = "convert mail"
indexStartIndices[ 50 ] = 115
indexStopIndices[ 50 ] = 115
linkNames[ 115 ] = "nethelp:netscape/Trouble:trouble_switch"
topicIndices[ 115 ] = 173

indexValue[ 51 ] = "cookies"
indexStartIndices[ 51 ] = 116
indexStopIndices[ 51 ] = 116
linkNames[ 116 ] = "nethelp:netscape/Navigatr:nav_cook"
topicIndices[ 116 ] = 96

indexValue[ 52 ] = "copying"
indexStartIndices[ 52 ] = 117
indexStopIndices[ 52 ] = 118
linkNames[ 117 ] = "nethelp:netscape/Composer:select_table"
topicIndices[ 117 ] = 108
linkNames[ 118 ] = "nethelp:netscape/Navigatr:nav_copy"
topicIndices[ 118 ] = 37

indexValue[ 53 ] = "creating messages"
indexStartIndices[ 53 ] = 119
indexStopIndices[ 53 ] = 120
linkNames[ 119 ] = "nethelp:netscape/Messengr:NEW_MESSAGE_WINDOW"
topicIndices[ 119 ] = 150
linkNames[ 120 ] = "nethelp:netscape/Messengr:mail_template"
topicIndices[ 120 ] = 151

indexValue[ 54 ] = "creating web pages"
indexStartIndices[ 54 ] = 121
indexStopIndices[ 54 ] = 121
linkNames[ 121 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 121 ] = 4

indexValue[ 55 ] = "cryptographic modules"
indexStartIndices[ 55 ] = 122
indexStopIndices[ 55 ] = 122
linkNames[ 122 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_CRYPTOMODS"
topicIndices[ 122 ] = 127

indexValue[ 56 ] = "customization"
indexStartIndices[ 56 ] = 123
indexStopIndices[ 56 ] = 133
linkNames[ 123 ] = "nethelp:netscape/Messengr:VIEW_MESSENGER_WINDOW"
topicIndices[ 123 ] = 153
linkNames[ 124 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS_HEADERS"
topicIndices[ 124 ] = 154
linkNames[ 125 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 125 ] = 72
linkNames[ 126 ] = "nethelp:netscape/Navigatr:nav_tool"
topicIndices[ 126 ] = 8
linkNames[ 127 ] = "nethelp:netscape/Navigatr:nav_compbar"
topicIndices[ 127 ] = 9
linkNames[ 128 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 128 ] = 155
linkNames[ 129 ] = "nethelp:netscape/Navigatr:nav_color"
topicIndices[ 129 ] = 10
linkNames[ 130 ] = "nethelp:netscape/Navigatr:nav_component"
topicIndices[ 130 ] = 11
linkNames[ 131 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 131 ] = 12
linkNames[ 132 ] = "nethelp:netscape/Navigatr:nav_lang"
topicIndices[ 132 ] = 27
linkNames[ 133 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 133 ] = 67

indexValue[ 57 ] = "decrypting messages"
indexStartIndices[ 57 ] = 134
indexStopIndices[ 57 ] = 134
linkNames[ 134 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 134 ] = 5

indexValue[ 58 ] = "decrypting pages"
indexStartIndices[ 58 ] = 135
indexStopIndices[ 58 ] = 135
linkNames[ 135 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 135 ] = 5

indexValue[ 59 ] = "deleting"
indexStartIndices[ 59 ] = 136
indexStopIndices[ 59 ] = 137
linkNames[ 136 ] = "nethelp:netscape/Composer:select_table"
topicIndices[ 136 ] = 108
linkNames[ 137 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 137 ] = 109

indexValue[ 60 ] = "deleting email"
indexStartIndices[ 60 ] = 138
indexStopIndices[ 60 ] = 138
linkNames[ 138 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 138 ] = 0

indexValue[ 61 ] = "delivery receipts"
indexStartIndices[ 61 ] = 139
indexStopIndices[ 61 ] = 139
linkNames[ 139 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 139 ] = 83

indexValue[ 62 ] = "dictionaries"
indexStartIndices[ 62 ] = 140
indexStopIndices[ 62 ] = 141
linkNames[ 140 ] = "nethelp:netscape/Composer:SPELL_CHECK"
topicIndices[ 140 ] = 21
linkNames[ 141 ] = "nethelp:netscape/Composer:EDIT_DICTIONARY"
topicIndices[ 141 ] = 22

indexValue[ 63 ] = "digital certificates"
indexStartIndices[ 63 ] = 142
indexStopIndices[ 63 ] = 146
linkNames[ 142 ] = "nethelp:netscape/Collabra:sec_getcerts"
topicIndices[ 142 ] = 146
linkNames[ 143 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO_OUTGOING"
topicIndices[ 143 ] = 118
linkNames[ 144 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_ISSUERS"
topicIndices[ 144 ] = 119
linkNames[ 145 ] = "nethelp:netscape/Collabra:HELP_SEC_PASS_UNSET"
topicIndices[ 145 ] = 62
linkNames[ 146 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 146 ] = 5

indexValue[ 64 ] = "digital signatures"
indexStartIndices[ 64 ] = 147
indexStopIndices[ 64 ] = 148
linkNames[ 147 ] = "nethelp:netscape/Collabra:sec_getcerts"
topicIndices[ 147 ] = 146
linkNames[ 148 ] = "nethelp:netscape/Trouble:cant_encrypt"
topicIndices[ 148 ] = 93

indexValue[ 65 ] = "directories"
indexStartIndices[ 65 ] = 149
indexStopIndices[ 65 ] = 149
linkNames[ 149 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 149 ] = 18

indexValue[ 66 ] = "directory servers"
indexStartIndices[ 66 ] = 150
indexStopIndices[ 66 ] = 154
linkNames[ 150 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 150 ] = 18
linkNames[ 151 ] = "nethelp:netscape/Messengr:SELECT_ADDRESSES"
topicIndices[ 151 ] = 178
linkNames[ 152 ] = "nethelp:netscape/Messengr:LDAP_SERVER_PROPERTIES"
topicIndices[ 152 ] = 179
linkNames[ 153 ] = "nethelp:netscape/Messengr:ADD_SERVER_OFFLINE"
topicIndices[ 153 ] = 55
linkNames[ 154 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 154 ] = 159

indexValue[ 67 ] = "disconnecting"
indexStartIndices[ 67 ] = 155
indexStopIndices[ 67 ] = 155
linkNames[ 155 ] = "nethelp:netscape/News:off_work"
topicIndices[ 155 ] = 106

indexValue[ 68 ] = "discussion groups"
indexStartIndices[ 68 ] = 156
indexStopIndices[ 68 ] = 161
linkNames[ 156 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 156 ] = 7
linkNames[ 157 ] = "nethelp:netscape/News:SUBSCRIBE_SEARCH"
topicIndices[ 157 ] = 147
linkNames[ 158 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_NEW"
topicIndices[ 158 ] = 148
linkNames[ 159 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 159 ] = 109
linkNames[ 160 ] = "nethelp:netscape/News:DOWNLOADING_NEW"
topicIndices[ 160 ] = 85
linkNames[ 161 ] = "nethelp:netscape/News:NEWS_DISCUSSION_GENERAL"
topicIndices[ 161 ] = 116

indexValue[ 69 ] = "disk quota"
indexStartIndices[ 69 ] = 162
indexStopIndices[ 69 ] = 162
linkNames[ 162 ] = "nethelp:netscape/Trouble:delete_failed"
topicIndices[ 162 ] = 39

indexValue[ 70 ] = "disk space"
indexStartIndices[ 70 ] = 163
indexStopIndices[ 70 ] = 164
linkNames[ 163 ] = "nethelp:netscape/Messengr:PREFERENCES_ADVANCED_DISKSPACE"
topicIndices[ 163 ] = 140
linkNames[ 164 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DISKSPACE"
topicIndices[ 164 ] = 105

indexValue[ 71 ] = "DNS"
indexStartIndices[ 71 ] = 165
indexStopIndices[ 71 ] = 165
linkNames[ 165 ] = "nethelp:netscape/Trouble:dns_entry"
topicIndices[ 165 ] = 86

indexValue[ 72 ] = "document properties"
indexStartIndices[ 72 ] = 166
indexStopIndices[ 72 ] = 166
linkNames[ 166 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_GENERAL"
topicIndices[ 166 ] = 129

indexValue[ 73 ] = "downloading directories"
indexStartIndices[ 73 ] = 167
indexStopIndices[ 73 ] = 167
linkNames[ 167 ] = "nethelp:netscape/Messengr:ADD_SERVER_OFFLINE"
topicIndices[ 167 ] = 55

indexValue[ 74 ] = "downloading email"
indexStartIndices[ 74 ] = 168
indexStopIndices[ 74 ] = 170
linkNames[ 168 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 168 ] = 82
linkNames[ 169 ] = "nethelp:netscape/Messengr:notifying"
topicIndices[ 169 ] = 14
linkNames[ 170 ] = "nethelp:netscape/Messengr:MAIL_FOLDER_PROPERTIES_DOWNLOAD"
topicIndices[ 170 ] = 139

indexValue[ 75 ] = "downloading mail"
indexStartIndices[ 75 ] = 171
indexStopIndices[ 75 ] = 175
linkNames[ 171 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 171 ] = 97
linkNames[ 172 ] = "nethelp:netscape/News:DOWNLOAD_MESSAGES"
topicIndices[ 172 ] = 98
linkNames[ 173 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 173 ] = 99
linkNames[ 174 ] = "nethelp:netscape/News:MAILNEWS_SELECT_ITEMS"
topicIndices[ 174 ] = 100
linkNames[ 175 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 175 ] = 101

indexValue[ 76 ] = "downloading newsgroups"
indexStartIndices[ 76 ] = 176
indexStopIndices[ 76 ] = 186
linkNames[ 176 ] = "nethelp:netscape/News:opening_groups_server"
topicIndices[ 176 ] = 84
linkNames[ 177 ] = "nethelp:netscape/News:DOWNLOADING_NEW"
topicIndices[ 177 ] = 85
linkNames[ 178 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DOWNLOAD"
topicIndices[ 178 ] = 104
linkNames[ 179 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DISKSPACE"
topicIndices[ 179 ] = 105
linkNames[ 180 ] = "nethelp:netscape/News:off_work"
topicIndices[ 180 ] = 106
linkNames[ 181 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 181 ] = 97
linkNames[ 182 ] = "nethelp:netscape/News:DOWNLOAD_MESSAGES"
topicIndices[ 182 ] = 98
linkNames[ 183 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 183 ] = 99
linkNames[ 184 ] = "nethelp:netscape/News:MAILNEWS_SELECT_ITEMS"
topicIndices[ 184 ] = 100
linkNames[ 185 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 185 ] = 101
linkNames[ 186 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE_GROUPS"
topicIndices[ 186 ] = 107

indexValue[ 77 ] = "editing bookmarks"
indexStartIndices[ 77 ] = 187
indexStopIndices[ 77 ] = 188
linkNames[ 187 ] = "nethelp:netscape/Navigatr:nav_bsearch"
topicIndices[ 187 ] = 35
linkNames[ 188 ] = "nethelp:netscape/Navigatr:nav_bfresh"
topicIndices[ 188 ] = 36

indexValue[ 78 ] = "editing"
indexStartIndices[ 78 ] = 189
indexStopIndices[ 78 ] = 199
linkNames[ 189 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 189 ] = 4
linkNames[ 190 ] = "nethelp:netscape/Composer:SPELL_CHECK"
topicIndices[ 190 ] = 21
linkNames[ 191 ] = "nethelp:netscape/Composer:EDIT_DICTIONARY"
topicIndices[ 191 ] = 22
linkNames[ 192 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 192 ] = 23
linkNames[ 193 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 193 ] = 24
linkNames[ 194 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 194 ] = 65
linkNames[ 195 ] = "nethelp:netscape/Composer:Inserting_a_table"
topicIndices[ 195 ] = 126
linkNames[ 196 ] = "nethelp:netscape/Composer:addtable"
topicIndices[ 196 ] = 171
linkNames[ 197 ] = "nethelp:netscape/Composer:Setting_table_properties"
topicIndices[ 197 ] = 102
linkNames[ 198 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 198 ] = 103
linkNames[ 199 ] = "nethelp:netscape/Composer:select_table"
topicIndices[ 199 ] = 108

indexValue[ 79 ] = "email, deleting"
indexStartIndices[ 79 ] = 200
indexStopIndices[ 79 ] = 200
linkNames[ 200 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 200 ] = 0

indexValue[ 80 ] = "email, reading"
indexStartIndices[ 80 ] = 201
indexStopIndices[ 80 ] = 201
linkNames[ 201 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 201 ] = 5

indexValue[ 81 ] = "email, receiving"
indexStartIndices[ 81 ] = 202
indexStopIndices[ 81 ] = 206
linkNames[ 202 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 202 ] = 13
linkNames[ 203 ] = "nethelp:netscape/Messengr:notifying"
topicIndices[ 203 ] = 14
linkNames[ 204 ] = "nethelp:netscape/Trouble:trouble_mail_notify"
topicIndices[ 204 ] = 15
linkNames[ 205 ] = "nethelp:netscape/Trouble:trouble_start_window"
topicIndices[ 205 ] = 16
linkNames[ 206 ] = "nethelp:netscape/Trouble:trouble_dialup_messg"
topicIndices[ 206 ] = 17

indexValue[ 82 ] = "email, recovering deleted"
indexStartIndices[ 82 ] = 207
indexStopIndices[ 82 ] = 208
linkNames[ 207 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 207 ] = 51
linkNames[ 208 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 208 ] = 51

indexValue[ 83 ] = "email, saving"
indexStartIndices[ 83 ] = 209
indexStopIndices[ 83 ] = 215
linkNames[ 209 ] = "nethelp:netscape/Messengr:mail_selecting"
topicIndices[ 209 ] = 134
linkNames[ 210 ] = "nethelp:netscape/Messengr:FILING_MESSAGES"
topicIndices[ 210 ] = 135
linkNames[ 211 ] = "nethelp:netscape/Messengr:rename_folder"
topicIndices[ 211 ] = 136
linkNames[ 212 ] = "nethelp:netscape/Messengr:OPENING_FOLDERS"
topicIndices[ 212 ] = 137
linkNames[ 213 ] = "nethelp:netscape/Messengr:MAIL_FOLDER_PROPERTIES_GENERAL"
topicIndices[ 213 ] = 138
linkNames[ 214 ] = "nethelp:netscape/Messengr:MAIL_FOLDER_PROPERTIES_DOWNLOAD"
topicIndices[ 214 ] = 139
linkNames[ 215 ] = "nethelp:netscape/Messengr:PREFERENCES_ADVANCED_DISKSPACE"
topicIndices[ 215 ] = 140

indexValue[ 84 ] = "email, searching"
indexStartIndices[ 84 ] = 216
indexStopIndices[ 84 ] = 216
linkNames[ 216 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS"
topicIndices[ 216 ] = 1

indexValue[ 85 ] = "email, sending"
indexStartIndices[ 85 ] = 217
indexStopIndices[ 85 ] = 227
linkNames[ 217 ] = "nethelp:netscape/Messengr:COMPOSING_MESSAGES"
topicIndices[ 217 ] = 161
linkNames[ 218 ] = "nethelp:netscape/Messengr:NEW_MESSAGE_WINDOW"
topicIndices[ 218 ] = 150
linkNames[ 219 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 219 ] = 44
linkNames[ 220 ] = "nethelp:netscape/Messengr:mail_replyto"
topicIndices[ 220 ] = 162
linkNames[ 221 ] = "nethelp:netscape/Messengr:FORWARD_MESSAGES"
topicIndices[ 221 ] = 52
linkNames[ 222 ] = "nethelp:netscape/Messengr:mail_template"
topicIndices[ 222 ] = 151
linkNames[ 223 ] = "nethelp:netscape/Messengr:HTML_MAIL_QUESTION"
topicIndices[ 223 ] = 163
linkNames[ 224 ] = "nethelp:netscape/Messengr:PALMPILOT_MAIL"
topicIndices[ 224 ] = 164
linkNames[ 225 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 225 ] = 83
linkNames[ 226 ] = "nethelp:netscape/Trouble:HELP_SEC_WARNING_FORWARDING"
topicIndices[ 226 ] = 53
linkNames[ 227 ] = "nethelp:netscape/Trouble:trouble_email_noshow"
topicIndices[ 227 ] = 45

indexValue[ 86 ] = "email, sorting"
indexStartIndices[ 86 ] = 228
indexStopIndices[ 86 ] = 230
linkNames[ 228 ] = "nethelp:netscape/Messengr:thread_mail"
topicIndices[ 228 ] = 117
linkNames[ 229 ] = "nethelp:netscape/Messengr:MAIL_FILTERS"
topicIndices[ 229 ] = 80
linkNames[ 230 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 230 ] = 6

indexValue[ 87 ] = "email filters"
indexStartIndices[ 87 ] = 231
indexStopIndices[ 87 ] = 231
linkNames[ 231 ] = "nethelp:netscape/Messengr:MAIL_FILTERS"
topicIndices[ 231 ] = 80

indexValue[ 88 ] = "enclosures"
indexStartIndices[ 88 ] = 232
indexStopIndices[ 88 ] = 234
linkNames[ 232 ] = "nethelp:netscape/Messengr:attaching_file"
topicIndices[ 232 ] = 47
linkNames[ 233 ] = "nethelp:netscape/Messengr:viewing_attachments"
topicIndices[ 233 ] = 48
linkNames[ 234 ] = "nethelp:netscape/Messengr:saving_attachment"
topicIndices[ 234 ] = 49

indexValue[ 89 ] = "encryption"
indexStartIndices[ 89 ] = 235
indexStopIndices[ 89 ] = 241
linkNames[ 235 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO_OUTGOING"
topicIndices[ 235 ] = 118
linkNames[ 236 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_NAVIGATOR"
topicIndices[ 236 ] = 120
linkNames[ 237 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_MESSENGER"
topicIndices[ 237 ] = 145
linkNames[ 238 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_CRYPTOMODS"
topicIndices[ 238 ] = 127
linkNames[ 239 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 239 ] = 19
linkNames[ 240 ] = "nethelp:netscape/Trouble:cant_encrypt"
topicIndices[ 240 ] = 93
linkNames[ 241 ] = "nethelp:netscape/Trouble:HELP_SEC_WARNING_FORWARDING"
topicIndices[ 241 ] = 53

indexValue[ 90 ] = "error messages"
indexStartIndices[ 90 ] = 242
indexStopIndices[ 90 ] = 251
linkNames[ 242 ] = "nethelp:netscape/Trouble:dns_entry"
topicIndices[ 242 ] = 86
linkNames[ 243 ] = "nethelp:netscape/Trouble:peer_reset"
topicIndices[ 243 ] = 87
linkNames[ 244 ] = "nethelp:netscape/Trouble:not_implemented"
topicIndices[ 244 ] = 88
linkNames[ 245 ] = "nethelp:netscape/Trouble:server_error"
topicIndices[ 245 ] = 89
linkNames[ 246 ] = "nethelp:netscape/Trouble:network_traffic"
topicIndices[ 246 ] = 77
linkNames[ 247 ] = "nethelp:netscape/Trouble:access_denied"
topicIndices[ 247 ] = 90
linkNames[ 248 ] = "nethelp:netscape/Trouble:no_news"
topicIndices[ 248 ] = 91
linkNames[ 249 ] = "nethelp:netscape/Trouble:address_book"
topicIndices[ 249 ] = 92
linkNames[ 250 ] = "nethelp:netscape/Trouble:cant_encrypt"
topicIndices[ 250 ] = 93
linkNames[ 251 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 251 ] = 5

indexValue[ 91 ] = "exploring the web"
indexStartIndices[ 91 ] = 252
indexStopIndices[ 91 ] = 255
linkNames[ 252 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 252 ] = 61
linkNames[ 253 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 253 ] = 31
linkNames[ 254 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 254 ] = 32
linkNames[ 255 ] = "nethelp:netscape/Navigatr:nav_bcreate"
topicIndices[ 255 ] = 33

indexValue[ 92 ] = "favorites"
indexStartIndices[ 92 ] = 256
indexStopIndices[ 92 ] = 258
linkNames[ 256 ] = "nethelp:netscape/Navigatr:nav_bcreate"
topicIndices[ 256 ] = 33
linkNames[ 257 ] = "nethelp:netscape/Navigatr:nav_bshort"
topicIndices[ 257 ] = 34
linkNames[ 258 ] = "nethelp:netscape/Navigatr:nav_borg"
topicIndices[ 258 ] = 174

indexValue[ 93 ] = "films"
indexStartIndices[ 93 ] = 259
indexStopIndices[ 93 ] = 259
linkNames[ 259 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 259 ] = 3

indexValue[ 94 ] = "filtering websites"
indexStartIndices[ 94 ] = 260
indexStopIndices[ 94 ] = 260
linkNames[ 260 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 260 ] = 133

indexValue[ 95 ] = "filters, mail"
indexStartIndices[ 95 ] = 261
indexStopIndices[ 95 ] = 262
linkNames[ 261 ] = "nethelp:netscape/Messengr:MAIL_FILTERS"
topicIndices[ 261 ] = 80
linkNames[ 262 ] = "nethelp:netscape/Messengr:FILTER_RULES"
topicIndices[ 262 ] = 81

indexValue[ 96 ] = "Find command"
indexStartIndices[ 96 ] = 263
indexStopIndices[ 96 ] = 263
linkNames[ 263 ] = "nethelp:netscape/Navigatr:nav_search"
topicIndices[ 263 ] = 59

indexValue[ 97 ] = "finding bookmarks"
indexStartIndices[ 97 ] = 264
indexStopIndices[ 97 ] = 264
linkNames[ 264 ] = "nethelp:netscape/Navigatr:nav_bsearch"
topicIndices[ 264 ] = 35

indexValue[ 98 ] = "finding messages"
indexStartIndices[ 98 ] = 265
indexStopIndices[ 98 ] = 265
linkNames[ 265 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS"
topicIndices[ 265 ] = 1

indexValue[ 99 ] = "finding websites"
indexStartIndices[ 99 ] = 266
indexStopIndices[ 99 ] = 266
linkNames[ 266 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 266 ] = 133

indexValue[ 100 ] = "firewalls"
indexStartIndices[ 100 ] = 267
indexStopIndices[ 100 ] = 267
linkNames[ 267 ] = "nethelp:netscape/Navigatr:nav_prox"
topicIndices[ 267 ] = 158

indexValue[ 101 ] = "folder properties"
indexStartIndices[ 101 ] = 268
indexStopIndices[ 101 ] = 268
linkNames[ 268 ] = "nethelp:netscape/Messengr:MAIL_FOLDER_PROPERTIES_GENERAL"
topicIndices[ 268 ] = 138

indexValue[ 102 ] = "fonts"
indexStartIndices[ 102 ] = 269
indexStopIndices[ 102 ] = 273
linkNames[ 269 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 269 ] = 23
linkNames[ 270 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 270 ] = 24
linkNames[ 271 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_GENERAL"
topicIndices[ 271 ] = 125
linkNames[ 272 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 272 ] = 72
linkNames[ 273 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 273 ] = 155

indexValue[ 103 ] = "formatting"
indexStartIndices[ 103 ] = 274
indexStopIndices[ 103 ] = 277
linkNames[ 274 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 274 ] = 23
linkNames[ 275 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 275 ] = 24
linkNames[ 276 ] = "nethelp:netscape/Composer:PROPERTIES_HRULE"
topicIndices[ 276 ] = 110
linkNames[ 277 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 277 ] = 65

indexValue[ 104 ] = "formatting, tables"
indexStartIndices[ 104 ] = 278
indexStopIndices[ 104 ] = 281
linkNames[ 278 ] = "nethelp:netscape/Composer:Inserting_a_table"
topicIndices[ 278 ] = 126
linkNames[ 279 ] = "nethelp:netscape/Composer:addtable"
topicIndices[ 279 ] = 171
linkNames[ 280 ] = "nethelp:netscape/Composer:Setting_table_properties"
topicIndices[ 280 ] = 102
linkNames[ 281 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 281 ] = 103

indexValue[ 105 ] = "forwarding messages"
indexStartIndices[ 105 ] = 282
indexStopIndices[ 105 ] = 283
linkNames[ 282 ] = "nethelp:netscape/Messengr:FORWARD_MESSAGES"
topicIndices[ 282 ] = 52
linkNames[ 283 ] = "nethelp:netscape/Trouble:HELP_SEC_WARNING_FORWARDING"
topicIndices[ 283 ] = 53

indexValue[ 106 ] = "frames"
indexStartIndices[ 106 ] = 284
indexStopIndices[ 106 ] = 284
linkNames[ 284 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 284 ] = 61

indexValue[ 107 ] = "frame source"
indexStartIndices[ 107 ] = 285
indexStopIndices[ 107 ] = 285
linkNames[ 285 ] = "nethelp:netscape/Navigatr:nav_save"
topicIndices[ 285 ] = 25

indexValue[ 108 ] = "FTP"
indexStartIndices[ 108 ] = 286
indexStopIndices[ 108 ] = 287
linkNames[ 286 ] = "nethelp:netscape/Composer:PUBLISH_FILES"
topicIndices[ 286 ] = 141
linkNames[ 287 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 287 ] = 30

indexValue[ 109 ] = "GIF"
indexStartIndices[ 109 ] = 288
indexStopIndices[ 109 ] = 290
linkNames[ 288 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 288 ] = 56
linkNames[ 289 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 289 ] = 57
linkNames[ 290 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 290 ] = 58

indexValue[ 110 ] = "Go menu"
indexStartIndices[ 110 ] = 291
indexStopIndices[ 110 ] = 292
linkNames[ 291 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 291 ] = 32
linkNames[ 292 ] = "nethelp:netscape/Navigatr:nav_histsearch"
topicIndices[ 292 ] = 168

indexValue[ 111 ] = "graphics"
indexStartIndices[ 111 ] = 293
indexStopIndices[ 111 ] = 298
linkNames[ 293 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 293 ] = 103
linkNames[ 294 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 294 ] = 56
linkNames[ 295 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 295 ] = 57
linkNames[ 296 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE_ALT"
topicIndices[ 296 ] = 94
linkNames[ 297 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 297 ] = 95
linkNames[ 298 ] = "nethelp:netscape/Composer:Linking_images"
topicIndices[ 298 ] = 71

indexValue[ 112 ] = "graphics file types"
indexStartIndices[ 112 ] = 299
indexStopIndices[ 112 ] = 299
linkNames[ 299 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 299 ] = 3

indexValue[ 113 ] = "groups, discussion"
indexStartIndices[ 113 ] = 300
indexStopIndices[ 113 ] = 305
linkNames[ 300 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 300 ] = 7
linkNames[ 301 ] = "nethelp:netscape/News:SUBSCRIBE_SEARCH"
topicIndices[ 301 ] = 147
linkNames[ 302 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_NEW"
topicIndices[ 302 ] = 148
linkNames[ 303 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 303 ] = 109
linkNames[ 304 ] = "nethelp:netscape/News:DOWNLOADING_NEW"
topicIndices[ 304 ] = 85
linkNames[ 305 ] = "nethelp:netscape/News:NEWS_DISCUSSION_GENERAL"
topicIndices[ 305 ] = 116

indexValue[ 114 ] = "hard disk"
indexStartIndices[ 114 ] = 306
indexStopIndices[ 114 ] = 306
linkNames[ 306 ] = "nethelp:netscape/Navigatr:nav_cache"
topicIndices[ 306 ] = 68

indexValue[ 115 ] = "headings"
indexStartIndices[ 115 ] = 307
indexStopIndices[ 115 ] = 307
linkNames[ 307 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 307 ] = 23

indexValue[ 116 ] = "helper applications"
indexStartIndices[ 116 ] = 308
indexStopIndices[ 116 ] = 308
linkNames[ 308 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 308 ] = 3

indexValue[ 117 ] = "History"
indexStartIndices[ 117 ] = 309
indexStopIndices[ 117 ] = 312
linkNames[ 309 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 309 ] = 32
linkNames[ 310 ] = "nethelp:netscape/Navigatr:nav_histsearch"
topicIndices[ 310 ] = 168
linkNames[ 311 ] = "nethelp:netscape/Navigatr:nav_bfresh"
topicIndices[ 311 ] = 36
linkNames[ 312 ] = "nethelp:netscape/Navigatr:nav_track"
topicIndices[ 312 ] = 2

indexValue[ 118 ] = "home page"
indexStartIndices[ 118 ] = 313
indexStopIndices[ 118 ] = 315
linkNames[ 313 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 313 ] = 61
linkNames[ 314 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 314 ] = 31
linkNames[ 315 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 315 ] = 12

indexValue[ 119 ] = "horizontal lines"
indexStartIndices[ 119 ] = 316
indexStopIndices[ 119 ] = 316
linkNames[ 316 ] = "nethelp:netscape/Composer:PROPERTIES_HRULE"
topicIndices[ 316 ] = 110

indexValue[ 120 ] = "hotlinks"
indexStartIndices[ 120 ] = 317
indexStopIndices[ 120 ] = 320
linkNames[ 317 ] = "nethelp:netscape/Composer:PROPERTIES_TARGET"
topicIndices[ 317 ] = 70
linkNames[ 318 ] = "nethelp:netscape/Composer:creating_links"
topicIndices[ 318 ] = 28
linkNames[ 319 ] = "nethelp:netscape/Composer:PROPERTIES_LINK"
topicIndices[ 319 ] = 29
linkNames[ 320 ] = "nethelp:netscape/Composer:Linking_images"
topicIndices[ 320 ] = 71

indexValue[ 121 ] = "HTML documents"
indexStartIndices[ 121 ] = 321
indexStopIndices[ 121 ] = 321
linkNames[ 321 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 321 ] = 4

indexValue[ 122 ] = "HTML formatting"
indexStartIndices[ 122 ] = 322
indexStopIndices[ 122 ] = 322
linkNames[ 322 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_FORMATTING"
topicIndices[ 322 ] = 123

indexValue[ 123 ] = "HTML mail"
indexStartIndices[ 123 ] = 323
indexStopIndices[ 123 ] = 324
linkNames[ 323 ] = "nethelp:netscape/Messengr:HTML_MAIL_QUESTION"
topicIndices[ 323 ] = 163
linkNames[ 324 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_FORMATTING"
topicIndices[ 324 ] = 123

indexValue[ 124 ] = "HTML messages"
indexStartIndices[ 124 ] = 325
indexStopIndices[ 124 ] = 325
linkNames[ 325 ] = "nethelp:netscape/News:NEWS_DISCUSSION_GENERAL"
topicIndices[ 325 ] = 116

indexValue[ 125 ] = "HTML source"
indexStartIndices[ 125 ] = 326
indexStopIndices[ 125 ] = 328
linkNames[ 326 ] = "nethelp:netscape/Composer:HTML_TAG"
topicIndices[ 326 ] = 64
linkNames[ 327 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 327 ] = 65
linkNames[ 328 ] = "nethelp:netscape/Navigatr:nav_checktec"
topicIndices[ 328 ] = 66

indexValue[ 126 ] = "hyperlinks"
indexStartIndices[ 126 ] = 329
indexStopIndices[ 126 ] = 333
linkNames[ 329 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 329 ] = 65
linkNames[ 330 ] = "nethelp:netscape/Composer:PROPERTIES_TARGET"
topicIndices[ 330 ] = 70
linkNames[ 331 ] = "nethelp:netscape/Composer:creating_links"
topicIndices[ 331 ] = 28
linkNames[ 332 ] = "nethelp:netscape/Composer:PROPERTIES_LINK"
topicIndices[ 332 ] = 29
linkNames[ 333 ] = "nethelp:netscape/Composer:Linking_images"
topicIndices[ 333 ] = 71

indexValue[ 127 ] = "icons"
indexStartIndices[ 127 ] = 334
indexStopIndices[ 127 ] = 336
linkNames[ 334 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO"
topicIndices[ 334 ] = 169
linkNames[ 335 ] = "nethelp:netscape/Navigatr:nav_tool"
topicIndices[ 335 ] = 8
linkNames[ 336 ] = "nethelp:netscape/Navigatr:nav_compbar"
topicIndices[ 336 ] = 9

indexValue[ 128 ] = "identity"
indexStartIndices[ 128 ] = 337
indexStopIndices[ 128 ] = 339
linkNames[ 337 ] = "nethelp:netscape/Collabra:sec_getcerts"
topicIndices[ 337 ] = 146
linkNames[ 338 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 338 ] = 60
linkNames[ 339 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 339 ] = 42

indexValue[ 129 ] = "images"
indexStartIndices[ 129 ] = 340
indexStopIndices[ 129 ] = 345
linkNames[ 340 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 340 ] = 103
linkNames[ 341 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 341 ] = 56
linkNames[ 342 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 342 ] = 57
linkNames[ 343 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE_ALT"
topicIndices[ 343 ] = 94
linkNames[ 344 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 344 ] = 95
linkNames[ 345 ] = "nethelp:netscape/Composer:Linking_images"
topicIndices[ 345 ] = 71

indexValue[ 130 ] = "IMAP mail"
indexStartIndices[ 130 ] = 346
indexStopIndices[ 130 ] = 360
linkNames[ 346 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 346 ] = 82
linkNames[ 347 ] = "nethelp:netscape/Messengr:viewing_attachments"
topicIndices[ 347 ] = 48
linkNames[ 348 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 348 ] = 0
linkNames[ 349 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 349 ] = 51
linkNames[ 350 ] = "nethelp:netscape/Messengr:OPENING_FOLDERS"
topicIndices[ 350 ] = 137
linkNames[ 351 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 351 ] = 130
linkNames[ 352 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_GENERAL"
topicIndices[ 352 ] = 142
linkNames[ 353 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_IMAP"
topicIndices[ 353 ] = 131
linkNames[ 354 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_ADVANCED"
topicIndices[ 354 ] = 75
linkNames[ 355 ] = "nethelp:netscape/Messengr:IMAP_UPGRADE"
topicIndices[ 355 ] = 143
linkNames[ 356 ] = "nethelp:netscape/Navigatr:nav_roam_intro"
topicIndices[ 356 ] = 76
linkNames[ 357 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 357 ] = 7
linkNames[ 358 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 358 ] = 97
linkNames[ 359 ] = "nethelp:netscape/News:DOWNLOAD_MESSAGES"
topicIndices[ 359 ] = 98
linkNames[ 360 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 360 ] = 99

indexValue[ 131 ] = "importing addresses"
indexStartIndices[ 131 ] = 361
indexStopIndices[ 131 ] = 361
linkNames[ 361 ] = "nethelp:netscape/Messengr:import_address_book"
topicIndices[ 361 ] = 175

indexValue[ 132 ] = "importing images"
indexStartIndices[ 132 ] = 362
indexStopIndices[ 132 ] = 365
linkNames[ 362 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 362 ] = 56
linkNames[ 363 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 363 ] = 57
linkNames[ 364 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE_ALT"
topicIndices[ 364 ] = 94
linkNames[ 365 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 365 ] = 95

indexValue[ 133 ] = "importing mail"
indexStartIndices[ 133 ] = 366
indexStopIndices[ 133 ] = 366
linkNames[ 366 ] = "nethelp:netscape/Messengr:import_address_book"
topicIndices[ 366 ] = 175

indexValue[ 134 ] = "inbox"
indexStartIndices[ 134 ] = 367
indexStopIndices[ 134 ] = 368
linkNames[ 367 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 367 ] = 13
linkNames[ 368 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 368 ] = 82

indexValue[ 135 ] = "indents"
indexStartIndices[ 135 ] = 369
indexStopIndices[ 135 ] = 369
linkNames[ 369 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 369 ] = 23

indexValue[ 136 ] = "Internet Keywords"
indexStartIndices[ 136 ] = 370
indexStopIndices[ 136 ] = 370
linkNames[ 370 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 370 ] = 133

indexValue[ 137 ] = "Java applets"
indexStartIndices[ 137 ] = 371
indexStopIndices[ 137 ] = 372
linkNames[ 371 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_APPLET"
topicIndices[ 371 ] = 132
linkNames[ 372 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 372 ] = 67

indexValue[ 138 ] = "Java"
indexStartIndices[ 138 ] = 373
indexStopIndices[ 138 ] = 375
linkNames[ 373 ] = "nethelp:netscape/Composer:HTML_TAG"
topicIndices[ 373 ] = 64
linkNames[ 374 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 374 ] = 65
linkNames[ 375 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 375 ] = 67

indexValue[ 139 ] = "joining newsgroups"
indexStartIndices[ 139 ] = 376
indexStopIndices[ 139 ] = 376
linkNames[ 376 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 376 ] = 7

indexValue[ 140 ] = "JPEG"
indexStartIndices[ 140 ] = 377
indexStopIndices[ 140 ] = 380
linkNames[ 377 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 377 ] = 56
linkNames[ 378 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 378 ] = 57
linkNames[ 379 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 379 ] = 95
linkNames[ 380 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 380 ] = 58

indexValue[ 141 ] = "jumps"
indexStartIndices[ 141 ] = 381
indexStopIndices[ 141 ] = 386
linkNames[ 381 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 381 ] = 65
linkNames[ 382 ] = "nethelp:netscape/Composer:PROPERTIES_TARGET"
topicIndices[ 382 ] = 70
linkNames[ 383 ] = "nethelp:netscape/Composer:creating_links"
topicIndices[ 383 ] = 28
linkNames[ 384 ] = "nethelp:netscape/Composer:PROPERTIES_LINK"
topicIndices[ 384 ] = 29
linkNames[ 385 ] = "nethelp:netscape/Composer:Linking_images"
topicIndices[ 385 ] = 71
linkNames[ 386 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 386 ] = 31

indexValue[ 142 ] = "key access"
indexStartIndices[ 142 ] = 387
indexStopIndices[ 142 ] = 387
linkNames[ 387 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_CRYPTOMODS"
topicIndices[ 387 ] = 127

indexValue[ 143 ] = "keyboard"
indexStartIndices[ 143 ] = 388
indexStopIndices[ 143 ] = 388
linkNames[ 388 ] = "nethelp:netscape/Trouble:trouble_navigate"
topicIndices[ 388 ] = 40

indexValue[ 144 ] = "language settings"
indexStartIndices[ 144 ] = 389
indexStopIndices[ 144 ] = 389
linkNames[ 389 ] = "nethelp:netscape/Navigatr:nav_lang"
topicIndices[ 389 ] = 27

indexValue[ 145 ] = "LDAP profiles"
indexStartIndices[ 145 ] = 390
indexStopIndices[ 145 ] = 390
linkNames[ 390 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 390 ] = 159

indexValue[ 146 ] = "lines"
indexStartIndices[ 146 ] = 391
indexStopIndices[ 146 ] = 391
linkNames[ 391 ] = "nethelp:netscape/Composer:PROPERTIES_HRULE"
topicIndices[ 391 ] = 110

indexValue[ 147 ] = "links"
indexStartIndices[ 147 ] = 392
indexStopIndices[ 147 ] = 397
linkNames[ 392 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 392 ] = 65
linkNames[ 393 ] = "nethelp:netscape/Composer:PROPERTIES_TARGET"
topicIndices[ 393 ] = 70
linkNames[ 394 ] = "nethelp:netscape/Composer:creating_links"
topicIndices[ 394 ] = 28
linkNames[ 395 ] = "nethelp:netscape/Composer:PROPERTIES_LINK"
topicIndices[ 395 ] = 29
linkNames[ 396 ] = "nethelp:netscape/Composer:Linking_images"
topicIndices[ 396 ] = 71
linkNames[ 397 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 397 ] = 31

indexValue[ 148 ] = "listing newsgroups"
indexStartIndices[ 148 ] = 398
indexStopIndices[ 148 ] = 401
linkNames[ 398 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 398 ] = 7
linkNames[ 399 ] = "nethelp:netscape/News:SUBSCRIBE_SEARCH"
topicIndices[ 399 ] = 147
linkNames[ 400 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_NEW"
topicIndices[ 400 ] = 148
linkNames[ 401 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 401 ] = 109

indexValue[ 149 ] = "lists, formatting"
indexStartIndices[ 149 ] = 402
indexStopIndices[ 149 ] = 402
linkNames[ 402 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 402 ] = 23

indexValue[ 150 ] = "loading pages"
indexStartIndices[ 150 ] = 403
indexStopIndices[ 150 ] = 404
linkNames[ 403 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 403 ] = 58
linkNames[ 404 ] = "nethelp:netscape/Navigatr:nav_cache"
topicIndices[ 404 ] = 68

indexValue[ 151 ] = "mail"
indexStartIndices[ 151 ] = 405
indexStopIndices[ 151 ] = 405
linkNames[ 405 ] = "nethelp:netscape/Messengr:COMPOSING_MESSAGES"
topicIndices[ 405 ] = 161

indexValue[ 152 ] = "mail, deleting"
indexStartIndices[ 152 ] = 406
indexStopIndices[ 152 ] = 406
linkNames[ 406 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 406 ] = 0

indexValue[ 153 ] = "mail, reading"
indexStartIndices[ 153 ] = 407
indexStopIndices[ 153 ] = 407
linkNames[ 407 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 407 ] = 5

indexValue[ 154 ] = "mail, receiving"
indexStartIndices[ 154 ] = 408
indexStopIndices[ 154 ] = 412
linkNames[ 408 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 408 ] = 13
linkNames[ 409 ] = "nethelp:netscape/Messengr:notifying"
topicIndices[ 409 ] = 14
linkNames[ 410 ] = "nethelp:netscape/Trouble:trouble_mail_notify"
topicIndices[ 410 ] = 15
linkNames[ 411 ] = "nethelp:netscape/Trouble:trouble_start_window"
topicIndices[ 411 ] = 16
linkNames[ 412 ] = "nethelp:netscape/Trouble:trouble_dialup_messg"
topicIndices[ 412 ] = 17

indexValue[ 155 ] = "mail, recovering deleted"
indexStartIndices[ 155 ] = 413
indexStopIndices[ 155 ] = 413
linkNames[ 413 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 413 ] = 51

indexValue[ 156 ] = "mail, saving"
indexStartIndices[ 156 ] = 414
indexStopIndices[ 156 ] = 414
linkNames[ 414 ] = "nethelp:netscape/Messengr:mail_selecting"
topicIndices[ 414 ] = 134

indexValue[ 157 ] = "mail, searching"
indexStartIndices[ 157 ] = 415
indexStopIndices[ 157 ] = 415
linkNames[ 415 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS"
topicIndices[ 415 ] = 1

indexValue[ 158 ] = "mail, sending"
indexStartIndices[ 158 ] = 416
indexStopIndices[ 158 ] = 426
linkNames[ 416 ] = "nethelp:netscape/Messengr:COMPOSING_MESSAGES"
topicIndices[ 416 ] = 161
linkNames[ 417 ] = "nethelp:netscape/Messengr:NEW_MESSAGE_WINDOW"
topicIndices[ 417 ] = 150
linkNames[ 418 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 418 ] = 44
linkNames[ 419 ] = "nethelp:netscape/Messengr:mail_replyto"
topicIndices[ 419 ] = 162
linkNames[ 420 ] = "nethelp:netscape/Messengr:FORWARD_MESSAGES"
topicIndices[ 420 ] = 52
linkNames[ 421 ] = "nethelp:netscape/Messengr:mail_template"
topicIndices[ 421 ] = 151
linkNames[ 422 ] = "nethelp:netscape/Messengr:HTML_MAIL_QUESTION"
topicIndices[ 422 ] = 163
linkNames[ 423 ] = "nethelp:netscape/Messengr:PALMPILOT_MAIL"
topicIndices[ 423 ] = 164
linkNames[ 424 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 424 ] = 83
linkNames[ 425 ] = "nethelp:netscape/Trouble:HELP_SEC_WARNING_FORWARDING"
topicIndices[ 425 ] = 53
linkNames[ 426 ] = "nethelp:netscape/Trouble:trouble_email_noshow"
topicIndices[ 426 ] = 45

indexValue[ 159 ] = "mail, sorting"
indexStartIndices[ 159 ] = 427
indexStopIndices[ 159 ] = 429
linkNames[ 427 ] = "nethelp:netscape/Messengr:thread_mail"
topicIndices[ 427 ] = 117
linkNames[ 428 ] = "nethelp:netscape/Messengr:MAIL_FILTERS"
topicIndices[ 428 ] = 80
linkNames[ 429 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 429 ] = 6

indexValue[ 160 ] = "Mail & Newsgroups set-up screen"
indexStartIndices[ 160 ] = 430
indexStopIndices[ 160 ] = 430
linkNames[ 430 ] = "nethelp:netscape/Trouble:trouble_mail_wzrd"
topicIndices[ 430 ] = 181

indexValue[ 161 ] = "Mail & Newsgroups Wizard"
indexStartIndices[ 161 ] = 431
indexStopIndices[ 161 ] = 431
linkNames[ 431 ] = "nethelp:netscape/Messengr:MAIL_NEWS_WIZARD"
topicIndices[ 431 ] = 167

indexValue[ 162 ] = "mail filters"
indexStartIndices[ 162 ] = 432
indexStopIndices[ 162 ] = 432
linkNames[ 432 ] = "nethelp:netscape/Messengr:MAIL_FILTERS"
topicIndices[ 432 ] = 80

indexValue[ 163 ] = "mailing lists"
indexStartIndices[ 163 ] = 433
indexStopIndices[ 163 ] = 433
linkNames[ 433 ] = "nethelp:netscape/Messengr:ADD_LIST_MAILING_LIST"
topicIndices[ 433 ] = 111

indexValue[ 164 ] = "mail servers"
indexStartIndices[ 164 ] = 434
indexStopIndices[ 164 ] = 439
linkNames[ 434 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 434 ] = 82
linkNames[ 435 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 435 ] = 130
linkNames[ 436 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_GENERAL"
topicIndices[ 436 ] = 142
linkNames[ 437 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_POP"
topicIndices[ 437 ] = 172
linkNames[ 438 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_IMAP"
topicIndices[ 438 ] = 131
linkNames[ 439 ] = "nethelp:netscape/Trouble:trouble_usr_passwd"
topicIndices[ 439 ] = 43

indexValue[ 165 ] = "MAPI"
indexStartIndices[ 165 ] = 440
indexStopIndices[ 165 ] = 440
linkNames[ 440 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 440 ] = 72

indexValue[ 166 ] = "memory cache"
indexStartIndices[ 166 ] = 441
indexStopIndices[ 166 ] = 442
linkNames[ 441 ] = "nethelp:netscape/Navigatr:nav_cache"
topicIndices[ 441 ] = 68
linkNames[ 442 ] = "nethelp:netscape/Trouble:trouble_cache"
topicIndices[ 442 ] = 69

indexValue[ 167 ] = "Message Center"
indexStartIndices[ 167 ] = 443
indexStopIndices[ 167 ] = 443
linkNames[ 443 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_WINDOW"
topicIndices[ 443 ] = 46

indexValue[ 168 ] = "Message Disposition Notification"
indexStartIndices[ 168 ] = 444
indexStopIndices[ 168 ] = 444
linkNames[ 444 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 444 ] = 83

indexValue[ 169 ] = "messages, deleting"
indexStartIndices[ 169 ] = 445
indexStopIndices[ 169 ] = 445
linkNames[ 445 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 445 ] = 0

indexValue[ 170 ] = "messages, newsgroup"
indexStartIndices[ 170 ] = 446
indexStopIndices[ 170 ] = 446
linkNames[ 446 ] = "nethelp:netscape/News:REPLYING"
topicIndices[ 446 ] = 74

indexValue[ 171 ] = "messages, reading"
indexStartIndices[ 171 ] = 447
indexStopIndices[ 171 ] = 448
linkNames[ 447 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 447 ] = 13
linkNames[ 448 ] = "nethelp:netscape/Trouble:decrypt_message"
topicIndices[ 448 ] = 5

indexValue[ 172 ] = "messages, receiving"
indexStartIndices[ 172 ] = 449
indexStopIndices[ 172 ] = 453
linkNames[ 449 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 449 ] = 13
linkNames[ 450 ] = "nethelp:netscape/Messengr:notifying"
topicIndices[ 450 ] = 14
linkNames[ 451 ] = "nethelp:netscape/Trouble:trouble_mail_notify"
topicIndices[ 451 ] = 15
linkNames[ 452 ] = "nethelp:netscape/Trouble:trouble_start_window"
topicIndices[ 452 ] = 16
linkNames[ 453 ] = "nethelp:netscape/Trouble:trouble_dialup_messg"
topicIndices[ 453 ] = 17

indexValue[ 173 ] = "messages, recovering deleted"
indexStartIndices[ 173 ] = 454
indexStopIndices[ 173 ] = 454
linkNames[ 454 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 454 ] = 51

indexValue[ 174 ] = "messages, saving"
indexStartIndices[ 174 ] = 455
indexStopIndices[ 174 ] = 462
linkNames[ 455 ] = "nethelp:netscape/Messengr:mail_selecting"
topicIndices[ 455 ] = 134
linkNames[ 456 ] = "nethelp:netscape/Messengr:saving_message_draft"
topicIndices[ 456 ] = 79
linkNames[ 457 ] = "nethelp:netscape/Messengr:FILING_MESSAGES"
topicIndices[ 457 ] = 135
linkNames[ 458 ] = "nethelp:netscape/Messengr:rename_folder"
topicIndices[ 458 ] = 136
linkNames[ 459 ] = "nethelp:netscape/Messengr:OPENING_FOLDERS"
topicIndices[ 459 ] = 137
linkNames[ 460 ] = "nethelp:netscape/Messengr:MAIL_FOLDER_PROPERTIES_GENERAL"
topicIndices[ 460 ] = 138
linkNames[ 461 ] = "nethelp:netscape/Messengr:MAIL_FOLDER_PROPERTIES_DOWNLOAD"
topicIndices[ 461 ] = 139
linkNames[ 462 ] = "nethelp:netscape/Messengr:PREFERENCES_ADVANCED_DISKSPACE"
topicIndices[ 462 ] = 140

indexValue[ 175 ] = "messages, searching"
indexStartIndices[ 175 ] = 463
indexStopIndices[ 175 ] = 463
linkNames[ 463 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS"
topicIndices[ 463 ] = 1

indexValue[ 176 ] = "messages, sending"
indexStartIndices[ 176 ] = 464
indexStopIndices[ 176 ] = 479
linkNames[ 464 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO_OUTGOING"
topicIndices[ 464 ] = 118
linkNames[ 465 ] = "nethelp:netscape/Messengr:COMPOSING_MESSAGES"
topicIndices[ 465 ] = 161
linkNames[ 466 ] = "nethelp:netscape/Messengr:NEW_MESSAGE_WINDOW"
topicIndices[ 466 ] = 150
linkNames[ 467 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 467 ] = 44
linkNames[ 468 ] = "nethelp:netscape/Messengr:mail_replyto"
topicIndices[ 468 ] = 162
linkNames[ 469 ] = "nethelp:netscape/Messengr:FORWARD_MESSAGES"
topicIndices[ 469 ] = 52
linkNames[ 470 ] = "nethelp:netscape/Messengr:mail_template"
topicIndices[ 470 ] = 151
linkNames[ 471 ] = "nethelp:netscape/Messengr:HTML_MAIL_QUESTION"
topicIndices[ 471 ] = 163
linkNames[ 472 ] = "nethelp:netscape/Messengr:PALMPILOT_MAIL"
topicIndices[ 472 ] = 164
linkNames[ 473 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_ADDRESSING"
topicIndices[ 473 ] = 152
linkNames[ 474 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MESSAGES"
topicIndices[ 474 ] = 50
linkNames[ 475 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_FORMATTING"
topicIndices[ 475 ] = 123
linkNames[ 476 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 476 ] = 83
linkNames[ 477 ] = "nethelp:netscape/News:about_posting"
topicIndices[ 477 ] = 73
linkNames[ 478 ] = "nethelp:netscape/Trouble:HELP_SEC_WARNING_FORWARDING"
topicIndices[ 478 ] = 53
linkNames[ 479 ] = "nethelp:netscape/Trouble:trouble_email_noshow"
topicIndices[ 479 ] = 45

indexValue[ 177 ] = "messages, sorting"
indexStartIndices[ 177 ] = 480
indexStopIndices[ 177 ] = 482
linkNames[ 480 ] = "nethelp:netscape/Messengr:thread_mail"
topicIndices[ 480 ] = 117
linkNames[ 481 ] = "nethelp:netscape/Messengr:MAIL_FILTERS"
topicIndices[ 481 ] = 80
linkNames[ 482 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 482 ] = 6

indexValue[ 178 ] = "message tampering"
indexStartIndices[ 178 ] = 483
indexStopIndices[ 178 ] = 483
linkNames[ 483 ] = "nethelp:netscape/Trouble:tamper"
topicIndices[ 483 ] = 182

indexValue[ 179 ] = "Meta tags"
indexStartIndices[ 179 ] = 484
indexStopIndices[ 179 ] = 484
linkNames[ 484 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_ADVANCED"
topicIndices[ 484 ] = 54

indexValue[ 180 ] = "MIME"
indexStartIndices[ 180 ] = 485
indexStopIndices[ 180 ] = 489
linkNames[ 485 ] = "nethelp:netscape/Messengr:attaching_file"
topicIndices[ 485 ] = 47
linkNames[ 486 ] = "nethelp:netscape/Messengr:viewing_attachments"
topicIndices[ 486 ] = 48
linkNames[ 487 ] = "nethelp:netscape/Messengr:saving_attachment"
topicIndices[ 487 ] = 49
linkNames[ 488 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MESSAGES"
topicIndices[ 488 ] = 50
linkNames[ 489 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 489 ] = 3

indexValue[ 181 ] = "movies"
indexStartIndices[ 181 ] = 490
indexStopIndices[ 181 ] = 490
linkNames[ 490 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 490 ] = 3

indexValue[ 182 ] = "name"
indexStartIndices[ 182 ] = 491
indexStopIndices[ 182 ] = 492
linkNames[ 491 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 491 ] = 60
linkNames[ 492 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 492 ] = 42

indexValue[ 183 ] = "navigating"
indexStartIndices[ 183 ] = 493
indexStopIndices[ 183 ] = 496
linkNames[ 493 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 493 ] = 31
linkNames[ 494 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 494 ] = 32
linkNames[ 495 ] = "nethelp:netscape/Trouble:trouble_navigate"
topicIndices[ 495 ] = 40
linkNames[ 496 ] = "nethelp:netscape/Trouble:trouble_stuck"
topicIndices[ 496 ] = 41

indexValue[ 184 ] = "Netcenter"
indexStartIndices[ 184 ] = 497
indexStopIndices[ 184 ] = 498
linkNames[ 497 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 497 ] = 61
linkNames[ 498 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 498 ] = 12

indexValue[ 185 ] = "Netsite field"
indexStartIndices[ 185 ] = 499
indexStopIndices[ 185 ] = 499
linkNames[ 499 ] = "nethelp:netscape/Trouble:trouble_common_clearloc"
topicIndices[ 499 ] = 38

indexValue[ 186 ] = "NetWatch"
indexStartIndices[ 186 ] = 500
indexStopIndices[ 186 ] = 500
linkNames[ 500 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 500 ] = 133

indexValue[ 187 ] = "New Card Dialog"
indexStartIndices[ 187 ] = 501
indexStopIndices[ 187 ] = 504
linkNames[ 501 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 501 ] = 60
linkNames[ 502 ] = "nethelp:netscape/Messengr:ADD_USER_NOTES"
topicIndices[ 502 ] = 156
linkNames[ 503 ] = "nethelp:netscape/Messengr:ADD_USER_CONTACT"
topicIndices[ 503 ] = 122
linkNames[ 504 ] = "nethelp:netscape/Messengr:ADD_USER_NETSCAPE_COOLTALK"
topicIndices[ 504 ] = 157

indexValue[ 188 ] = "new mail alert"
indexStartIndices[ 188 ] = 505
indexStopIndices[ 188 ] = 507
linkNames[ 505 ] = "nethelp:netscape/Messengr:notifying"
topicIndices[ 505 ] = 14
linkNames[ 506 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 506 ] = 72
linkNames[ 507 ] = "nethelp:netscape/Trouble:trouble_mail_notify"
topicIndices[ 507 ] = 15

indexValue[ 189 ] = "new messages"
indexStartIndices[ 189 ] = 508
indexStopIndices[ 189 ] = 508
linkNames[ 508 ] = "nethelp:netscape/News:DOWNLOADING_NEW"
topicIndices[ 508 ] = 85

indexValue[ 190 ] = "newsgroup access problems"
indexStartIndices[ 190 ] = 509
indexStopIndices[ 190 ] = 509
linkNames[ 509 ] = "nethelp:netscape/Trouble:trouble_news"
topicIndices[ 509 ] = 115

indexValue[ 191 ] = "newsgroup properties"
indexStartIndices[ 191 ] = 510
indexStopIndices[ 191 ] = 510
linkNames[ 510 ] = "nethelp:netscape/News:NEWS_DISCUSSION_GENERAL"
topicIndices[ 510 ] = 116

indexValue[ 192 ] = "newsgroups"
indexStartIndices[ 192 ] = 511
indexStopIndices[ 192 ] = 514
linkNames[ 511 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 511 ] = 7
linkNames[ 512 ] = "nethelp:netscape/News:SUBSCRIBE_SEARCH"
topicIndices[ 512 ] = 147
linkNames[ 513 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_NEW"
topicIndices[ 513 ] = 148
linkNames[ 514 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 514 ] = 109

indexValue[ 193 ] = "newsgroup server"
indexStartIndices[ 193 ] = 515
indexStopIndices[ 193 ] = 520
linkNames[ 515 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_GROUPSERVER"
topicIndices[ 515 ] = 112
linkNames[ 516 ] = "nethelp:netscape/News:opening_groups_server"
topicIndices[ 516 ] = 84
linkNames[ 517 ] = "nethelp:netscape/News:ADD_SERVER"
topicIndices[ 517 ] = 113
linkNames[ 518 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 518 ] = 19
linkNames[ 519 ] = "nethelp:netscape/Trouble:trouble_no_news2"
topicIndices[ 519 ] = 114
linkNames[ 520 ] = "nethelp:netscape/Trouble:trouble_news"
topicIndices[ 520 ] = 115

indexValue[ 194 ] = "No DNS entry"
indexStartIndices[ 194 ] = 521
indexStopIndices[ 194 ] = 521
linkNames[ 521 ] = "nethelp:netscape/Trouble:dns_entry"
topicIndices[ 521 ] = 86

indexValue[ 195 ] = "not implemented error"
indexStartIndices[ 195 ] = 522
indexStopIndices[ 195 ] = 522
linkNames[ 522 ] = "nethelp:netscape/Trouble:not_implemented"
topicIndices[ 522 ] = 88

indexValue[ 196 ] = "offline icon"
indexStartIndices[ 196 ] = 523
indexStopIndices[ 196 ] = 523
linkNames[ 523 ] = "nethelp:netscape/News:off_work"
topicIndices[ 523 ] = 106

indexValue[ 197 ] = "offline viewing"
indexStartIndices[ 197 ] = 524
indexStopIndices[ 197 ] = 529
linkNames[ 524 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DOWNLOAD"
topicIndices[ 524 ] = 104
linkNames[ 525 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DISKSPACE"
topicIndices[ 525 ] = 105
linkNames[ 526 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 526 ] = 97
linkNames[ 527 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 527 ] = 99
linkNames[ 528 ] = "nethelp:netscape/News:MAILNEWS_SELECT_ITEMS"
topicIndices[ 528 ] = 100
linkNames[ 529 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE_GROUPS"
topicIndices[ 529 ] = 107

indexValue[ 198 ] = "offline"
indexStartIndices[ 198 ] = 530
indexStopIndices[ 198 ] = 531
linkNames[ 530 ] = "nethelp:netscape/Messengr:ADD_SERVER_OFFLINE"
topicIndices[ 530 ] = 55
linkNames[ 531 ] = "nethelp:netscape/News:off_work"
topicIndices[ 531 ] = 106

indexValue[ 199 ] = "offline preferences"
indexStartIndices[ 199 ] = 532
indexStopIndices[ 199 ] = 532
linkNames[ 532 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 532 ] = 101

indexValue[ 200 ] = "Open Page dialog"
indexStartIndices[ 200 ] = 533
indexStopIndices[ 200 ] = 533
linkNames[ 533 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 533 ] = 31

indexValue[ 201 ] = "organizer"
indexStartIndices[ 201 ] = 534
indexStopIndices[ 201 ] = 534
linkNames[ 534 ] = "nethelp:netscape/Messengr:CREATE_ADD_BOOK"
topicIndices[ 534 ] = 149

indexValue[ 202 ] = "organizing messages"
indexStartIndices[ 202 ] = 535
indexStopIndices[ 202 ] = 535
linkNames[ 535 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 535 ] = 6

indexValue[ 203 ] = "padlock icon"
indexStartIndices[ 203 ] = 536
indexStopIndices[ 203 ] = 536
linkNames[ 536 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO"
topicIndices[ 536 ] = 169

indexValue[ 204 ] = "Page Composer"
indexStartIndices[ 204 ] = 537
indexStopIndices[ 204 ] = 537
linkNames[ 537 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 537 ] = 4

indexValue[ 205 ] = "page info"
indexStartIndices[ 205 ] = 538
indexStopIndices[ 205 ] = 539
linkNames[ 538 ] = "nethelp:netscape/Navigatr:nav_checksec"
topicIndices[ 538 ] = 170
linkNames[ 539 ] = "nethelp:netscape/Navigatr:nav_checktec"
topicIndices[ 539 ] = 66

indexValue[ 206 ] = "page properties"
indexStartIndices[ 206 ] = 540
indexStopIndices[ 206 ] = 541
linkNames[ 540 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_GENERAL"
topicIndices[ 540 ] = 129
linkNames[ 541 ] = "nethelp:netscape/Composer:DOCUMENT_PROPERTIES_APPEARANCE"
topicIndices[ 541 ] = 124

indexValue[ 207 ] = "page source"
indexStartIndices[ 207 ] = 542
indexStopIndices[ 207 ] = 543
linkNames[ 542 ] = "nethelp:netscape/Composer:HTML_TAG"
topicIndices[ 542 ] = 64
linkNames[ 543 ] = "nethelp:netscape/Navigatr:nav_save"
topicIndices[ 543 ] = 25

indexValue[ 208 ] = "Page Wizard"
indexStartIndices[ 208 ] = 544
indexStopIndices[ 208 ] = 544
linkNames[ 544 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 544 ] = 4

indexValue[ 209 ] = "PalmPilot"
indexStartIndices[ 209 ] = 545
indexStopIndices[ 209 ] = 545
linkNames[ 545 ] = "nethelp:netscape/Messengr:PALMPILOT_MAIL"
topicIndices[ 545 ] = 164

indexValue[ 210 ] = "paragraph styles"
indexStartIndices[ 210 ] = 546
indexStopIndices[ 210 ] = 546
linkNames[ 546 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 546 ] = 23

indexValue[ 211 ] = "password"
indexStartIndices[ 211 ] = 547
indexStopIndices[ 211 ] = 550
linkNames[ 547 ] = "nethelp:netscape/Collabra:HELP_SEC_PASS_UNSET"
topicIndices[ 547 ] = 62
linkNames[ 548 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 548 ] = 19
linkNames[ 549 ] = "nethelp:netscape/Trouble:forgot_pass"
topicIndices[ 549 ] = 63
linkNames[ 550 ] = "nethelp:netscape/Trouble:trouble_usr_passwd"
topicIndices[ 550 ] = 43

indexValue[ 212 ] = "personal card"
indexStartIndices[ 212 ] = 551
indexStopIndices[ 212 ] = 551
linkNames[ 551 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 551 ] = 42

indexValue[ 213 ] = "personal cards"
indexStartIndices[ 213 ] = 552
indexStopIndices[ 213 ] = 552
linkNames[ 552 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 552 ] = 60

indexValue[ 214 ] = "personalizing Navigator"
indexStartIndices[ 214 ] = 553
indexStopIndices[ 214 ] = 557
linkNames[ 553 ] = "nethelp:netscape/Navigatr:nav_tool"
topicIndices[ 553 ] = 8
linkNames[ 554 ] = "nethelp:netscape/Navigatr:nav_compbar"
topicIndices[ 554 ] = 9
linkNames[ 555 ] = "nethelp:netscape/Navigatr:nav_color"
topicIndices[ 555 ] = 10
linkNames[ 556 ] = "nethelp:netscape/Navigatr:nav_component"
topicIndices[ 556 ] = 11
linkNames[ 557 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 557 ] = 12

indexValue[ 215 ] = "phonebook"
indexStartIndices[ 215 ] = 558
indexStopIndices[ 215 ] = 558
linkNames[ 558 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 558 ] = 18

indexValue[ 216 ] = "pictures"
indexStartIndices[ 216 ] = 559
indexStopIndices[ 216 ] = 562
linkNames[ 559 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 559 ] = 56
linkNames[ 560 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 560 ] = 57
linkNames[ 561 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE_ALT"
topicIndices[ 561 ] = 94
linkNames[ 562 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 562 ] = 95

indexValue[ 217 ] = "Pinpoint Addressing"
indexStartIndices[ 217 ] = 563
indexStopIndices[ 217 ] = 563
linkNames[ 563 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 563 ] = 44

indexValue[ 218 ] = "plug-ins"
indexStartIndices[ 218 ] = 564
indexStopIndices[ 218 ] = 565
linkNames[ 564 ] = "nethelp:netscape/Composer:COMPOSER_PLUGINS"
topicIndices[ 564 ] = 144
linkNames[ 565 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 565 ] = 3

indexValue[ 219 ] = "point sizes"
indexStartIndices[ 219 ] = 566
indexStopIndices[ 219 ] = 566
linkNames[ 566 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 566 ] = 24

indexValue[ 220 ] = "POP mail"
indexStartIndices[ 220 ] = 567
indexStopIndices[ 220 ] = 574
linkNames[ 567 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 567 ] = 82
linkNames[ 568 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 568 ] = 0
linkNames[ 569 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 569 ] = 51
linkNames[ 570 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 570 ] = 130
linkNames[ 571 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_GENERAL"
topicIndices[ 571 ] = 142
linkNames[ 572 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_POP"
topicIndices[ 572 ] = 172
linkNames[ 573 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 573 ] = 97
linkNames[ 574 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 574 ] = 99

indexValue[ 221 ] = "port numbers"
indexStartIndices[ 221 ] = 575
indexStopIndices[ 221 ] = 575
linkNames[ 575 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 575 ] = 19

indexValue[ 222 ] = "posting"
indexStartIndices[ 222 ] = 576
indexStopIndices[ 222 ] = 577
linkNames[ 576 ] = "nethelp:netscape/News:about_posting"
topicIndices[ 576 ] = 73
linkNames[ 577 ] = "nethelp:netscape/News:REPLYING"
topicIndices[ 577 ] = 74

indexValue[ 223 ] = "PowerPlant error"
indexStartIndices[ 223 ] = 578
indexStopIndices[ 223 ] = 578
linkNames[ 578 ] = "nethelp:netscape/Trouble:power_plant"
topicIndices[ 578 ] = 26

indexValue[ 224 ] = "preferences, Composer"
indexStartIndices[ 224 ] = 579
indexStopIndices[ 224 ] = 581
linkNames[ 579 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 579 ] = 56
linkNames[ 580 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_GENERAL"
topicIndices[ 580 ] = 125
linkNames[ 581 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 581 ] = 30

indexValue[ 225 ] = "preferences, Messenger"
indexStartIndices[ 225 ] = 582
indexStopIndices[ 225 ] = 600
linkNames[ 582 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_MESSENGER"
topicIndices[ 582 ] = 145
linkNames[ 583 ] = "nethelp:netscape/Messengr:VIEW_MESSENGER_WINDOW"
topicIndices[ 583 ] = 153
linkNames[ 584 ] = "nethelp:netscape/Messengr:MAIL_NEWS_WIZARD"
topicIndices[ 584 ] = 167
linkNames[ 585 ] = "nethelp:netscape/Messengr:mail_replyto"
topicIndices[ 585 ] = 162
linkNames[ 586 ] = "nethelp:netscape/Messengr:HTML_MAIL_QUESTION"
topicIndices[ 586 ] = 163
linkNames[ 587 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 587 ] = 60
linkNames[ 588 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 588 ] = 72
linkNames[ 589 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 589 ] = 42
linkNames[ 590 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 590 ] = 130
linkNames[ 591 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_GENERAL"
topicIndices[ 591 ] = 142
linkNames[ 592 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_POP"
topicIndices[ 592 ] = 172
linkNames[ 593 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_IMAP"
topicIndices[ 593 ] = 131
linkNames[ 594 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_ADDRESSING"
topicIndices[ 594 ] = 152
linkNames[ 595 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MESSAGES"
topicIndices[ 595 ] = 50
linkNames[ 596 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 596 ] = 6
linkNames[ 597 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_FORMATTING"
topicIndices[ 597 ] = 123
linkNames[ 598 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 598 ] = 83
linkNames[ 599 ] = "nethelp:netscape/Messengr:PREFERENCES_ADVANCED_DISKSPACE"
topicIndices[ 599 ] = 140
linkNames[ 600 ] = "nethelp:netscape/Trouble:trouble_start_window"
topicIndices[ 600 ] = 16

indexValue[ 226 ] = "preferences, Navigator"
indexStartIndices[ 226 ] = 601
indexStopIndices[ 226 ] = 616
linkNames[ 601 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 601 ] = 155
linkNames[ 602 ] = "nethelp:netscape/Navigatr:nav_color"
topicIndices[ 602 ] = 10
linkNames[ 603 ] = "nethelp:netscape/Navigatr:nav_component"
topicIndices[ 603 ] = 11
linkNames[ 604 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 604 ] = 12
linkNames[ 605 ] = "nethelp:netscape/Navigatr:nav_track"
topicIndices[ 605 ] = 2
linkNames[ 606 ] = "nethelp:netscape/Navigatr:nav_lang"
topicIndices[ 606 ] = 27
linkNames[ 607 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 607 ] = 3
linkNames[ 608 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 608 ] = 58
linkNames[ 609 ] = "nethelp:netscape/Navigatr:nav_cook"
topicIndices[ 609 ] = 96
linkNames[ 610 ] = "nethelp:netscape/Navigatr:nav_cache"
topicIndices[ 610 ] = 68
linkNames[ 611 ] = "nethelp:netscape/Navigatr:nav_smartup"
topicIndices[ 611 ] = 20
linkNames[ 612 ] = "nethelp:netscape/Navigatr:nav_prox"
topicIndices[ 612 ] = 158
linkNames[ 613 ] = "nethelp:netscape/Navigatr:nav_roam_intro"
topicIndices[ 613 ] = 76
linkNames[ 614 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 614 ] = 159
linkNames[ 615 ] = "nethelp:netscape/Navigatr:nav_roam_files"
topicIndices[ 615 ] = 160
linkNames[ 616 ] = "nethelp:netscape/Trouble:trouble_cache"
topicIndices[ 616 ] = 69

indexValue[ 227 ] = "preferences, newsgroups"
indexStartIndices[ 227 ] = 617
indexStopIndices[ 227 ] = 621
linkNames[ 617 ] = "nethelp:netscape/News:NEWS_DISCUSSION_GENERAL"
topicIndices[ 617 ] = 116
linkNames[ 618 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 618 ] = 19
linkNames[ 619 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 619 ] = 101
linkNames[ 620 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE_GROUPS"
topicIndices[ 620 ] = 107
linkNames[ 621 ] = "nethelp:netscape/Trouble:trouble_news"
topicIndices[ 621 ] = 115

indexValue[ 228 ] = "preferences, security"
indexStartIndices[ 228 ] = 622
indexStopIndices[ 228 ] = 623
linkNames[ 622 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_NAVIGATOR"
topicIndices[ 622 ] = 120
linkNames[ 623 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 623 ] = 67

indexValue[ 229 ] = "printing"
indexStartIndices[ 229 ] = 624
indexStopIndices[ 229 ] = 625
linkNames[ 624 ] = "nethelp:netscape/Messengr:mail_selecting"
topicIndices[ 624 ] = 134
linkNames[ 625 ] = "nethelp:netscape/Navigatr:nav_print"
topicIndices[ 625 ] = 183

indexValue[ 230 ] = "privacy"
indexStartIndices[ 230 ] = 626
indexStopIndices[ 230 ] = 629
linkNames[ 626 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO_OUTGOING"
topicIndices[ 626 ] = 118
linkNames[ 627 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_ISSUERS"
topicIndices[ 627 ] = 119
linkNames[ 628 ] = "nethelp:netscape/Collabra:HELP_SEC_PASS_UNSET"
topicIndices[ 628 ] = 62
linkNames[ 629 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_NAVIGATOR"
topicIndices[ 629 ] = 120

indexValue[ 231 ] = "properties"
indexStartIndices[ 231 ] = 630
indexStopIndices[ 231 ] = 630
linkNames[ 630 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 630 ] = 19

indexValue[ 232 ] = "proxies"
indexStartIndices[ 232 ] = 631
indexStopIndices[ 232 ] = 631
linkNames[ 631 ] = "nethelp:netscape/Navigatr:nav_prox"
topicIndices[ 631 ] = 158

indexValue[ 233 ] = "publishing"
indexStartIndices[ 233 ] = 632
indexStopIndices[ 233 ] = 633
linkNames[ 632 ] = "nethelp:netscape/Composer:PUBLISH_FILES"
topicIndices[ 632 ] = 141
linkNames[ 633 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 633 ] = 30

indexValue[ 234 ] = "QuickTime"
indexStartIndices[ 234 ] = 634
indexStopIndices[ 234 ] = 635
linkNames[ 634 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 634 ] = 56
linkNames[ 635 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE"
topicIndices[ 635 ] = 57

indexValue[ 235 ] = "quoting text"
indexStartIndices[ 235 ] = 636
indexStopIndices[ 235 ] = 638
linkNames[ 636 ] = "nethelp:netscape/Messengr:mail_replyto"
topicIndices[ 636 ] = 162
linkNames[ 637 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 637 ] = 72
linkNames[ 638 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MESSAGES"
topicIndices[ 638 ] = 50

indexValue[ 236 ] = "reading email"
indexStartIndices[ 236 ] = 639
indexStopIndices[ 236 ] = 639
linkNames[ 639 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 639 ] = 13

indexValue[ 237 ] = "read receipts"
indexStartIndices[ 237 ] = 640
indexStopIndices[ 237 ] = 640
linkNames[ 640 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 640 ] = 83

indexValue[ 238 ] = "recipient types"
indexStartIndices[ 238 ] = 641
indexStopIndices[ 238 ] = 641
linkNames[ 641 ] = "nethelp:netscape/Messengr:ADDRESSING_MESSAGE"
topicIndices[ 641 ] = 44

indexValue[ 239 ] = "related websites"
indexStartIndices[ 239 ] = 642
indexStopIndices[ 239 ] = 642
linkNames[ 642 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 642 ] = 133

indexValue[ 240 ] = "remote access"
indexStartIndices[ 240 ] = 643
indexStopIndices[ 240 ] = 643
linkNames[ 643 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 643 ] = 159

indexValue[ 241 ] = "removing"
indexStartIndices[ 241 ] = 644
indexStopIndices[ 241 ] = 644
linkNames[ 644 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 644 ] = 109

indexValue[ 242 ] = "replying (newsgroups)"
indexStartIndices[ 242 ] = 645
indexStopIndices[ 242 ] = 645
linkNames[ 645 ] = "nethelp:netscape/News:REPLYING"
topicIndices[ 645 ] = 74

indexValue[ 243 ] = "replying to mail"
indexStartIndices[ 243 ] = 646
indexStopIndices[ 243 ] = 647
linkNames[ 646 ] = "nethelp:netscape/Messengr:mail_replyto"
topicIndices[ 646 ] = 162
linkNames[ 647 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 647 ] = 42

indexValue[ 244 ] = "resolution"
indexStartIndices[ 244 ] = 648
indexStopIndices[ 244 ] = 649
linkNames[ 648 ] = "nethelp:netscape/Composer:PROPERTIES_IMAGE_ALT"
topicIndices[ 648 ] = 94
linkNames[ 649 ] = "nethelp:netscape/Composer:IMAGE_CONVERSION"
topicIndices[ 649 ] = 95

indexValue[ 245 ] = "responding"
indexStartIndices[ 245 ] = 650
indexStopIndices[ 245 ] = 650
linkNames[ 650 ] = "nethelp:netscape/News:REPLYING"
topicIndices[ 650 ] = 74

indexValue[ 246 ] = "retracing"
indexStartIndices[ 246 ] = 651
indexStopIndices[ 246 ] = 652
linkNames[ 651 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 651 ] = 32
linkNames[ 652 ] = "nethelp:netscape/Navigatr:nav_histsearch"
topicIndices[ 652 ] = 168

indexValue[ 247 ] = "return address"
indexStartIndices[ 247 ] = 653
indexStopIndices[ 247 ] = 653
linkNames[ 653 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 653 ] = 42

indexValue[ 248 ] = "return receipts"
indexStartIndices[ 248 ] = 654
indexStopIndices[ 248 ] = 654
linkNames[ 654 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_RECEIPTS"
topicIndices[ 654 ] = 83

indexValue[ 249 ] = "roaming access"
indexStartIndices[ 249 ] = 655
indexStopIndices[ 249 ] = 657
linkNames[ 655 ] = "nethelp:netscape/Navigatr:nav_roam_intro"
topicIndices[ 655 ] = 76
linkNames[ 656 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 656 ] = 159
linkNames[ 657 ] = "nethelp:netscape/Navigatr:nav_roam_files"
topicIndices[ 657 ] = 160

indexValue[ 250 ] = "rows, table"
indexStartIndices[ 250 ] = 658
indexStopIndices[ 250 ] = 659
linkNames[ 658 ] = "nethelp:netscape/Composer:addtable"
topicIndices[ 658 ] = 171
linkNames[ 659 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 659 ] = 103

indexValue[ 251 ] = "rules, inserting"
indexStartIndices[ 251 ] = 660
indexStopIndices[ 251 ] = 661
linkNames[ 660 ] = "nethelp:netscape/Composer:PROPERTIES_HRULE"
topicIndices[ 660 ] = 110
linkNames[ 661 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 661 ] = 103

indexValue[ 252 ] = "saving"
indexStartIndices[ 252 ] = 662
indexStopIndices[ 252 ] = 664
linkNames[ 662 ] = "nethelp:netscape/Composer:browse_new_page"
topicIndices[ 662 ] = 78
linkNames[ 663 ] = "nethelp:netscape/Messengr:saving_message_draft"
topicIndices[ 663 ] = 79
linkNames[ 664 ] = "nethelp:netscape/Messengr:saving_attachment"
topicIndices[ 664 ] = 49

indexValue[ 253 ] = "saving email"
indexStartIndices[ 253 ] = 665
indexStopIndices[ 253 ] = 665
linkNames[ 665 ] = "nethelp:netscape/Messengr:mail_selecting"
topicIndices[ 665 ] = 134

indexValue[ 254 ] = "saving images"
indexStartIndices[ 254 ] = 666
indexStopIndices[ 254 ] = 666
linkNames[ 666 ] = "nethelp:netscape/Navigatr:nav_save"
topicIndices[ 666 ] = 25

indexValue[ 255 ] = "saving web pages"
indexStartIndices[ 255 ] = 667
indexStopIndices[ 255 ] = 667
linkNames[ 667 ] = "nethelp:netscape/Navigatr:nav_save"
topicIndices[ 667 ] = 25

indexValue[ 256 ] = "searching"
indexStartIndices[ 256 ] = 668
indexStopIndices[ 256 ] = 675
linkNames[ 668 ] = "nethelp:netscape/Messengr:SEARCH_ADDRESS_BOOK"
topicIndices[ 668 ] = 165
linkNames[ 669 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 669 ] = 18
linkNames[ 670 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS"
topicIndices[ 670 ] = 1
linkNames[ 671 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS_OPTIONS"
topicIndices[ 671 ] = 166
linkNames[ 672 ] = "nethelp:netscape/Navigatr:nav_search"
topicIndices[ 672 ] = 59
linkNames[ 673 ] = "nethelp:netscape/Navigatr:nav_bsearch"
topicIndices[ 673 ] = 35
linkNames[ 674 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 674 ] = 7
linkNames[ 675 ] = "nethelp:netscape/News:SUBSCRIBE_SEARCH"
topicIndices[ 675 ] = 147

indexValue[ 257 ] = "security"
indexStartIndices[ 257 ] = 676
indexStopIndices[ 257 ] = 690
linkNames[ 676 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO"
topicIndices[ 676 ] = 169
linkNames[ 677 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO_OUTGOING"
topicIndices[ 677 ] = 118
linkNames[ 678 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_ISSUERS"
topicIndices[ 678 ] = 119
linkNames[ 679 ] = "nethelp:netscape/Collabra:HELP_SEC_PASS_UNSET"
topicIndices[ 679 ] = 62
linkNames[ 680 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_NAVIGATOR"
topicIndices[ 680 ] = 120
linkNames[ 681 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_MESSENGER"
topicIndices[ 681 ] = 145
linkNames[ 682 ] = "nethelp:netscape/Collabra:HELP_SEC_PREFS_APPLET"
topicIndices[ 682 ] = 132
linkNames[ 683 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_CRYPTOMODS"
topicIndices[ 683 ] = 127
linkNames[ 684 ] = "nethelp:netscape/Navigatr:nav_checksec"
topicIndices[ 684 ] = 170
linkNames[ 685 ] = "nethelp:netscape/Navigatr:nav_cook"
topicIndices[ 685 ] = 96
linkNames[ 686 ] = "nethelp:netscape/Navigatr:nav_prox"
topicIndices[ 686 ] = 158
linkNames[ 687 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 687 ] = 19
linkNames[ 688 ] = "nethelp:netscape/Trouble:forgot_pass"
topicIndices[ 688 ] = 63
linkNames[ 689 ] = "nethelp:netscape/Trouble:HELP_SEC_WARNING_FORWARDING"
topicIndices[ 689 ] = 53
linkNames[ 690 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 690 ] = 67

indexValue[ 258 ] = "selecting newsgroups"
indexStartIndices[ 258 ] = 691
indexStopIndices[ 258 ] = 691
linkNames[ 691 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 691 ] = 7

indexValue[ 259 ] = "selecting tables"
indexStartIndices[ 259 ] = 692
indexStopIndices[ 259 ] = 692
linkNames[ 692 ] = "nethelp:netscape/Composer:select_table"
topicIndices[ 692 ] = 108

indexValue[ 260 ] = "server error"
indexStartIndices[ 260 ] = 693
indexStopIndices[ 260 ] = 696
linkNames[ 693 ] = "nethelp:netscape/Trouble:dns_entry"
topicIndices[ 693 ] = 86
linkNames[ 694 ] = "nethelp:netscape/Trouble:server_error"
topicIndices[ 694 ] = 89
linkNames[ 695 ] = "nethelp:netscape/Trouble:network_traffic"
topicIndices[ 695 ] = 77
linkNames[ 696 ] = "nethelp:netscape/Trouble:no_news"
topicIndices[ 696 ] = 91

indexValue[ 261 ] = "servers"
indexStartIndices[ 261 ] = 697
indexStopIndices[ 261 ] = 699
linkNames[ 697 ] = "nethelp:netscape/Collabra:HELP_SEC_INFO"
topicIndices[ 697 ] = 169
linkNames[ 698 ] = "nethelp:netscape/Messengr:SEARCH_LDAP"
topicIndices[ 698 ] = 18
linkNames[ 699 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 699 ] = 159

indexValue[ 262 ] = "servers, IMAP"
indexStartIndices[ 262 ] = 700
indexStopIndices[ 262 ] = 702
linkNames[ 700 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_ADVANCED"
topicIndices[ 700 ] = 75
linkNames[ 701 ] = "nethelp:netscape/Navigatr:nav_roam_intro"
topicIndices[ 701 ] = 76
linkNames[ 702 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 702 ] = 7

indexValue[ 263 ] = "servers, mail"
indexStartIndices[ 263 ] = 703
indexStopIndices[ 263 ] = 710
linkNames[ 703 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 703 ] = 82
linkNames[ 704 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 704 ] = 0
linkNames[ 705 ] = "nethelp:netscape/Messengr:LDAP_SERVER_PROPERTIES"
topicIndices[ 705 ] = 179
linkNames[ 706 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 706 ] = 130
linkNames[ 707 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_GENERAL"
topicIndices[ 707 ] = 142
linkNames[ 708 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_POP"
topicIndices[ 708 ] = 172
linkNames[ 709 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_IMAP"
topicIndices[ 709 ] = 131
linkNames[ 710 ] = "nethelp:netscape/Trouble:trouble_usr_passwd"
topicIndices[ 710 ] = 43

indexValue[ 264 ] = "servers, newsgroup"
indexStartIndices[ 264 ] = 711
indexStopIndices[ 264 ] = 716
linkNames[ 711 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_GROUPSERVER"
topicIndices[ 711 ] = 112
linkNames[ 712 ] = "nethelp:netscape/News:opening_groups_server"
topicIndices[ 712 ] = 84
linkNames[ 713 ] = "nethelp:netscape/News:ADD_SERVER"
topicIndices[ 713 ] = 113
linkNames[ 714 ] = "nethelp:netscape/News:DISCUSSION_HOST_PROPERTIES"
topicIndices[ 714 ] = 19
linkNames[ 715 ] = "nethelp:netscape/Trouble:trouble_no_news2"
topicIndices[ 715 ] = 114
linkNames[ 716 ] = "nethelp:netscape/Trouble:trouble_news"
topicIndices[ 716 ] = 115

indexValue[ 265 ] = "servers, proxy"
indexStartIndices[ 265 ] = 717
indexStopIndices[ 265 ] = 717
linkNames[ 717 ] = "nethelp:netscape/Navigatr:nav_prox"
topicIndices[ 717 ] = 158

indexValue[ 266 ] = "servers, web"
indexStartIndices[ 266 ] = 718
indexStopIndices[ 266 ] = 720
linkNames[ 718 ] = "nethelp:netscape/Composer:PUBLISH_FILES"
topicIndices[ 718 ] = 141
linkNames[ 719 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 719 ] = 30
linkNames[ 720 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 720 ] = 159

indexValue[ 267 ] = "settings, Composer"
indexStartIndices[ 267 ] = 721
indexStopIndices[ 267 ] = 723
linkNames[ 721 ] = "nethelp:netscape/Composer:Insert_an_image"
topicIndices[ 721 ] = 56
linkNames[ 722 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_GENERAL"
topicIndices[ 722 ] = 125
linkNames[ 723 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 723 ] = 30

indexValue[ 268 ] = "settings, Messenger"
indexStartIndices[ 268 ] = 724
indexStopIndices[ 268 ] = 725
linkNames[ 724 ] = "nethelp:netscape/Messengr:VIEW_MESSENGER_WINDOW"
topicIndices[ 724 ] = 153
linkNames[ 725 ] = "nethelp:netscape/Messengr:MAIL_NEWS_WIZARD"
topicIndices[ 725 ] = 167

indexValue[ 269 ] = "settings, Navigator"
indexStartIndices[ 269 ] = 726
indexStopIndices[ 269 ] = 740
linkNames[ 726 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 726 ] = 155
linkNames[ 727 ] = "nethelp:netscape/Navigatr:nav_color"
topicIndices[ 727 ] = 10
linkNames[ 728 ] = "nethelp:netscape/Navigatr:nav_component"
topicIndices[ 728 ] = 11
linkNames[ 729 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 729 ] = 12
linkNames[ 730 ] = "nethelp:netscape/Navigatr:nav_track"
topicIndices[ 730 ] = 2
linkNames[ 731 ] = "nethelp:netscape/Navigatr:nav_lang"
topicIndices[ 731 ] = 27
linkNames[ 732 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 732 ] = 3
linkNames[ 733 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 733 ] = 58
linkNames[ 734 ] = "nethelp:netscape/Navigatr:nav_cook"
topicIndices[ 734 ] = 96
linkNames[ 735 ] = "nethelp:netscape/Navigatr:nav_cache"
topicIndices[ 735 ] = 68
linkNames[ 736 ] = "nethelp:netscape/Navigatr:nav_smartup"
topicIndices[ 736 ] = 20
linkNames[ 737 ] = "nethelp:netscape/Navigatr:nav_prox"
topicIndices[ 737 ] = 158
linkNames[ 738 ] = "nethelp:netscape/Navigatr:nav_roam_intro"
topicIndices[ 738 ] = 76
linkNames[ 739 ] = "nethelp:netscape/Navigatr:nav_roam_profile"
topicIndices[ 739 ] = 159
linkNames[ 740 ] = "nethelp:netscape/Navigatr:nav_roam_files"
topicIndices[ 740 ] = 160

indexValue[ 270 ] = "settings, newsgroup"
indexStartIndices[ 270 ] = 741
indexStopIndices[ 270 ] = 741
linkNames[ 741 ] = "nethelp:netscape/News:NEWS_DISCUSSION_GENERAL"
topicIndices[ 741 ] = 116

indexValue[ 271 ] = "settings, security"
indexStartIndices[ 271 ] = 742
indexStopIndices[ 271 ] = 742
linkNames[ 742 ] = "nethelp:netscape/Trouble:java_alert"
topicIndices[ 742 ] = 67

indexValue[ 272 ] = "setup"
indexStartIndices[ 272 ] = 743
indexStopIndices[ 272 ] = 743
linkNames[ 743 ] = "nethelp:netscape/Messengr:MAIL_NEWS_WIZARD"
topicIndices[ 743 ] = 167

indexValue[ 273 ] = "setup, Messenger"
indexStartIndices[ 273 ] = 744
indexStopIndices[ 273 ] = 744
linkNames[ 744 ] = "nethelp:netscape/Messengr:OPEN_INBOX"
topicIndices[ 744 ] = 13

indexValue[ 274 ] = "shortcuts"
indexStartIndices[ 274 ] = 745
indexStopIndices[ 274 ] = 747
linkNames[ 745 ] = "nethelp:netscape/Navigatr:nav_bcreate"
topicIndices[ 745 ] = 33
linkNames[ 746 ] = "nethelp:netscape/Navigatr:nav_bshort"
topicIndices[ 746 ] = 34
linkNames[ 747 ] = "nethelp:netscape/Navigatr:nav_borg"
topicIndices[ 747 ] = 174

indexValue[ 275 ] = "signatures"
indexStartIndices[ 275 ] = 748
indexStopIndices[ 275 ] = 749
linkNames[ 748 ] = "nethelp:netscape/Collabra:sec_getcerts"
topicIndices[ 748 ] = 146
linkNames[ 749 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 749 ] = 42

indexValue[ 276 ] = "Signers panel"
indexStartIndices[ 276 ] = 750
indexStopIndices[ 276 ] = 750
linkNames[ 750 ] = "nethelp:netscape/Trouble:cant_encrypt"
topicIndices[ 750 ] = 93

indexValue[ 277 ] = "Smart Browsing"
indexStartIndices[ 277 ] = 751
indexStopIndices[ 277 ] = 751
linkNames[ 751 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 751 ] = 133

indexValue[ 278 ] = "smart cards"
indexStartIndices[ 278 ] = 752
indexStopIndices[ 278 ] = 752
linkNames[ 752 ] = "nethelp:netscape/Collabra:HELP_SEC_CERTS_CRYPTOMODS"
topicIndices[ 752 ] = 127

indexValue[ 279 ] = "SmartUpdate"
indexStartIndices[ 279 ] = 753
indexStopIndices[ 279 ] = 753
linkNames[ 753 ] = "nethelp:netscape/Navigatr:nav_smartup"
topicIndices[ 753 ] = 20

indexValue[ 280 ] = "SMTP host"
indexStartIndices[ 280 ] = 754
indexStopIndices[ 280 ] = 755
linkNames[ 754 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 754 ] = 130
linkNames[ 755 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_GENERAL"
topicIndices[ 755 ] = 142

indexValue[ 281 ] = "sorting"
indexStartIndices[ 281 ] = 756
indexStopIndices[ 281 ] = 756
linkNames[ 756 ] = "nethelp:netscape/Messengr:thread_mail"
topicIndices[ 756 ] = 117

indexValue[ 282 ] = "sound"
indexStartIndices[ 282 ] = 757
indexStopIndices[ 282 ] = 757
linkNames[ 757 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 757 ] = 72

indexValue[ 283 ] = "sound files"
indexStartIndices[ 283 ] = 758
indexStopIndices[ 283 ] = 758
linkNames[ 758 ] = "nethelp:netscape/Navigatr:nav_helper"
topicIndices[ 758 ] = 3

indexValue[ 284 ] = "source code"
indexStartIndices[ 284 ] = 759
indexStopIndices[ 284 ] = 759
linkNames[ 759 ] = "nethelp:netscape/Navigatr:nav_checktec"
topicIndices[ 759 ] = 66

indexValue[ 285 ] = "speed"
indexStartIndices[ 285 ] = 760
indexStopIndices[ 285 ] = 760
linkNames[ 760 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 760 ] = 58

indexValue[ 286 ] = "spellchecking"
indexStartIndices[ 286 ] = 761
indexStopIndices[ 286 ] = 761
linkNames[ 761 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MESSAGES"
topicIndices[ 761 ] = 50

indexValue[ 287 ] = "spell checking"
indexStartIndices[ 287 ] = 762
indexStopIndices[ 287 ] = 763
linkNames[ 762 ] = "nethelp:netscape/Composer:SPELL_CHECK"
topicIndices[ 762 ] = 21
linkNames[ 763 ] = "nethelp:netscape/Composer:EDIT_DICTIONARY"
topicIndices[ 763 ] = 22

indexValue[ 288 ] = "SSL"
indexStartIndices[ 288 ] = 764
indexStopIndices[ 288 ] = 765
linkNames[ 764 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 764 ] = 130
linkNames[ 765 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_IMAP"
topicIndices[ 765 ] = 131

indexValue[ 289 ] = "starting Messenger"
indexStartIndices[ 289 ] = 766
indexStopIndices[ 289 ] = 766
linkNames[ 766 ] = "nethelp:netscape/Messengr:MAIL_NEWS_WIZARD"
topicIndices[ 766 ] = 167

indexValue[ 290 ] = "start page"
indexStartIndices[ 290 ] = 767
indexStopIndices[ 290 ] = 767
linkNames[ 767 ] = "nethelp:netscape/Navigatr:nav_home"
topicIndices[ 767 ] = 12

indexValue[ 291 ] = "startup"
indexStartIndices[ 291 ] = 768
indexStopIndices[ 291 ] = 771
linkNames[ 768 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 768 ] = 61
linkNames[ 769 ] = "nethelp:netscape/Navigatr:nav_component"
topicIndices[ 769 ] = 11
linkNames[ 770 ] = "nethelp:netscape/Navigatr:nav_roam_files"
topicIndices[ 770 ] = 160
linkNames[ 771 ] = "nethelp:netscape/Trouble:trouble_start_window"
topicIndices[ 771 ] = 16

indexValue[ 292 ] = "storing email"
indexStartIndices[ 292 ] = 772
indexStopIndices[ 292 ] = 772
linkNames[ 772 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_COPIES"
topicIndices[ 772 ] = 6

indexValue[ 293 ] = "subscribing"
indexStartIndices[ 293 ] = 773
indexStopIndices[ 293 ] = 776
linkNames[ 773 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_ALL"
topicIndices[ 773 ] = 7
linkNames[ 774 ] = "nethelp:netscape/News:SUBSCRIBE_SEARCH"
topicIndices[ 774 ] = 147
linkNames[ 775 ] = "nethelp:netscape/News:SUBSCRIBE_LIST_NEW"
topicIndices[ 775 ] = 148
linkNames[ 776 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 776 ] = 109

indexValue[ 294 ] = "subscripts"
indexStartIndices[ 294 ] = 777
indexStopIndices[ 294 ] = 777
linkNames[ 777 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 777 ] = 24

indexValue[ 295 ] = "superscripts"
indexStartIndices[ 295 ] = 778
indexStopIndices[ 295 ] = 778
linkNames[ 778 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 778 ] = 24

indexValue[ 296 ] = "symbols"
indexStartIndices[ 296 ] = 779
indexStopIndices[ 296 ] = 779
linkNames[ 779 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 779 ] = 155

indexValue[ 297 ] = "synchronization"
indexStartIndices[ 297 ] = 780
indexStopIndices[ 297 ] = 784
linkNames[ 780 ] = "nethelp:netscape/Messengr:IMAP_and_POP3"
topicIndices[ 780 ] = 82
linkNames[ 781 ] = "nethelp:netscape/Navigatr:nav_roam_files"
topicIndices[ 781 ] = 160
linkNames[ 782 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 782 ] = 97
linkNames[ 783 ] = "nethelp:netscape/News:DOWNLOAD_MESSAGES"
topicIndices[ 783 ] = 98
linkNames[ 784 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 784 ] = 99

indexValue[ 298 ] = "tables"
indexStartIndices[ 298 ] = 785
indexStopIndices[ 298 ] = 791
linkNames[ 785 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 785 ] = 23
linkNames[ 786 ] = "nethelp:netscape/Composer:EXTRA_HTML"
topicIndices[ 786 ] = 65
linkNames[ 787 ] = "nethelp:netscape/Composer:Inserting_a_table"
topicIndices[ 787 ] = 126
linkNames[ 788 ] = "nethelp:netscape/Composer:addtable"
topicIndices[ 788 ] = 171
linkNames[ 789 ] = "nethelp:netscape/Composer:Setting_table_properties"
topicIndices[ 789 ] = 102
linkNames[ 790 ] = "nethelp:netscape/Composer:TABLE_PROPERTIES"
topicIndices[ 790 ] = 103
linkNames[ 791 ] = "nethelp:netscape/Composer:select_table"
topicIndices[ 791 ] = 108

indexValue[ 299 ] = "targets"
indexStartIndices[ 299 ] = 792
indexStopIndices[ 299 ] = 794
linkNames[ 792 ] = "nethelp:netscape/Composer:PROPERTIES_TARGET"
topicIndices[ 792 ] = 70
linkNames[ 793 ] = "nethelp:netscape/Composer:creating_links"
topicIndices[ 793 ] = 28
linkNames[ 794 ] = "nethelp:netscape/Composer:PROPERTIES_LINK"
topicIndices[ 794 ] = 29

indexValue[ 300 ] = "templates"
indexStartIndices[ 300 ] = 795
indexStopIndices[ 300 ] = 797
linkNames[ 795 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 795 ] = 4
linkNames[ 796 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_GENERAL"
topicIndices[ 796 ] = 125
linkNames[ 797 ] = "nethelp:netscape/Messengr:mail_template"
topicIndices[ 797 ] = 151

indexValue[ 301 ] = "text"
indexStartIndices[ 301 ] = 798
indexStopIndices[ 301 ] = 801
linkNames[ 798 ] = "nethelp:netscape/Composer:SPELL_CHECK"
topicIndices[ 798 ] = 21
linkNames[ 799 ] = "nethelp:netscape/Composer:EDIT_DICTIONARY"
topicIndices[ 799 ] = 22
linkNames[ 800 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 800 ] = 23
linkNames[ 801 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 801 ] = 24

indexValue[ 302 ] = "text, selecting"
indexStartIndices[ 302 ] = 802
indexStopIndices[ 302 ] = 802
linkNames[ 802 ] = "nethelp:netscape/Navigatr:nav_copy"
topicIndices[ 802 ] = 37

indexValue[ 303 ] = "text attributes"
indexStartIndices[ 303 ] = 803
indexStopIndices[ 303 ] = 804
linkNames[ 803 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 803 ] = 24
linkNames[ 804 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 804 ] = 72

indexValue[ 304 ] = "text editors"
indexStartIndices[ 304 ] = 805
indexStopIndices[ 304 ] = 805
linkNames[ 805 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_GENERAL"
topicIndices[ 805 ] = 125

indexValue[ 305 ] = "text styles"
indexStartIndices[ 305 ] = 806
indexStopIndices[ 305 ] = 806
linkNames[ 806 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 806 ] = 24

indexValue[ 306 ] = "threading"
indexStartIndices[ 306 ] = 807
indexStopIndices[ 306 ] = 807
linkNames[ 807 ] = "nethelp:netscape/Messengr:thread_mail"
topicIndices[ 807 ] = 117

indexValue[ 307 ] = "threads"
indexStartIndices[ 307 ] = 808
indexStopIndices[ 307 ] = 808
linkNames[ 808 ] = "nethelp:netscape/News:REPLYING"
topicIndices[ 808 ] = 74

indexValue[ 308 ] = "three-pane"
indexStartIndices[ 308 ] = 809
indexStopIndices[ 308 ] = 809
linkNames[ 809 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_WINDOW"
topicIndices[ 809 ] = 46

indexValue[ 309 ] = "titles"
indexStartIndices[ 309 ] = 810
indexStopIndices[ 309 ] = 810
linkNames[ 810 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 810 ] = 23

indexValue[ 310 ] = "TLS"
indexStartIndices[ 310 ] = 811
indexStopIndices[ 310 ] = 812
linkNames[ 811 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAILSERVER"
topicIndices[ 811 ] = 130
linkNames[ 812 ] = "nethelp:netscape/Messengr:MAILSERVER_PROPERTY_IMAP"
topicIndices[ 812 ] = 131

indexValue[ 311 ] = "toolbars"
indexStartIndices[ 311 ] = 813
indexStopIndices[ 311 ] = 814
linkNames[ 813 ] = "nethelp:netscape/Navigatr:nav_tool"
topicIndices[ 813 ] = 8
linkNames[ 814 ] = "nethelp:netscape/Navigatr:nav_compbar"
topicIndices[ 814 ] = 9

indexValue[ 312 ] = "tools"
indexStartIndices[ 312 ] = 815
indexStopIndices[ 312 ] = 815
linkNames[ 815 ] = "nethelp:netscape/Composer:COMPOSER_PLUGINS"
topicIndices[ 815 ] = 144

indexValue[ 313 ] = "too much network traffic error"
indexStartIndices[ 313 ] = 816
indexStopIndices[ 313 ] = 816
linkNames[ 816 ] = "nethelp:netscape/Trouble:network_traffic"
topicIndices[ 816 ] = 77

indexValue[ 314 ] = "tracking page visits"
indexStartIndices[ 314 ] = 817
indexStopIndices[ 314 ] = 817
linkNames[ 817 ] = "nethelp:netscape/Navigatr:nav_track"
topicIndices[ 817 ] = 2

indexValue[ 315 ] = "trash"
indexStartIndices[ 315 ] = 818
indexStopIndices[ 315 ] = 819
linkNames[ 818 ] = "nethelp:netscape/Messengr:about_deleting_email"
topicIndices[ 818 ] = 0
linkNames[ 819 ] = "nethelp:netscape/Messengr:moving_to_trash"
topicIndices[ 819 ] = 51

indexValue[ 316 ] = "typefaces"
indexStartIndices[ 316 ] = 820
indexStopIndices[ 316 ] = 822
linkNames[ 820 ] = "nethelp:netscape/Composer:PROPERTIES_PARAGRAPH"
topicIndices[ 820 ] = 23
linkNames[ 821 ] = "nethelp:netscape/Composer:PROPERTIES_CHARACTER"
topicIndices[ 821 ] = 24
linkNames[ 822 ] = "nethelp:netscape/Navigatr:nav_font"
topicIndices[ 822 ] = 155

indexValue[ 317 ] = "typing addresses"
indexStartIndices[ 317 ] = 823
indexStopIndices[ 317 ] = 823
linkNames[ 823 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 823 ] = 31

indexValue[ 318 ] = "unsubscribing"
indexStartIndices[ 318 ] = 824
indexStopIndices[ 318 ] = 824
linkNames[ 824 ] = "nethelp:netscape/News:UNSUBSCRIBE"
topicIndices[ 824 ] = 109

indexValue[ 319 ] = "updates, software"
indexStartIndices[ 319 ] = 825
indexStopIndices[ 319 ] = 825
linkNames[ 825 ] = "nethelp:netscape/Navigatr:nav_smartup"
topicIndices[ 825 ] = 20

indexValue[ 320 ] = "updating bookmarks"
indexStartIndices[ 320 ] = 826
indexStopIndices[ 320 ] = 826
linkNames[ 826 ] = "nethelp:netscape/Navigatr:nav_bfresh"
topicIndices[ 826 ] = 36

indexValue[ 321 ] = "updating"
indexStartIndices[ 321 ] = 827
indexStopIndices[ 321 ] = 830
linkNames[ 827 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 827 ] = 60
linkNames[ 828 ] = "nethelp:netscape/News:opening_groups_server"
topicIndices[ 828 ] = 84
linkNames[ 829 ] = "nethelp:netscape/News:DOWNLOADING_NEW"
topicIndices[ 829 ] = 85
linkNames[ 830 ] = "nethelp:netscape/Trouble:trouble_dialup_messg"
topicIndices[ 830 ] = 17

indexValue[ 322 ] = "uploading pages"
indexStartIndices[ 322 ] = 831
indexStopIndices[ 322 ] = 832
linkNames[ 831 ] = "nethelp:netscape/Composer:PUBLISH_FILES"
topicIndices[ 831 ] = 141
linkNames[ 832 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 832 ] = 30

indexValue[ 323 ] = "URLs"
indexStartIndices[ 323 ] = 833
indexStopIndices[ 323 ] = 844
linkNames[ 833 ] = "nethelp:netscape/Composer:creating_links"
topicIndices[ 833 ] = 28
linkNames[ 834 ] = "nethelp:netscape/Composer:PROPERTIES_LINK"
topicIndices[ 834 ] = 29
linkNames[ 835 ] = "nethelp:netscape/Composer:PREFERENCES_EDITOR_PUBLISH"
topicIndices[ 835 ] = 30
linkNames[ 836 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 836 ] = 31
linkNames[ 837 ] = "nethelp:netscape/Navigatr:nav_retrace"
topicIndices[ 837 ] = 32
linkNames[ 838 ] = "nethelp:netscape/Navigatr:nav_bcreate"
topicIndices[ 838 ] = 33
linkNames[ 839 ] = "nethelp:netscape/Navigatr:nav_bshort"
topicIndices[ 839 ] = 34
linkNames[ 840 ] = "nethelp:netscape/Navigatr:nav_bsearch"
topicIndices[ 840 ] = 35
linkNames[ 841 ] = "nethelp:netscape/Navigatr:nav_bfresh"
topicIndices[ 841 ] = 36
linkNames[ 842 ] = "nethelp:netscape/Navigatr:nav_copy"
topicIndices[ 842 ] = 37
linkNames[ 843 ] = "nethelp:netscape/Navigatr:nav_track"
topicIndices[ 843 ] = 2
linkNames[ 844 ] = "nethelp:netscape/Trouble:trouble_common_clearloc"
topicIndices[ 844 ] = 38

indexValue[ 324 ] = "username"
indexStartIndices[ 324 ] = 845
indexStopIndices[ 324 ] = 846
linkNames[ 845 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 845 ] = 42
linkNames[ 846 ] = "nethelp:netscape/Trouble:trouble_usr_passwd"
topicIndices[ 846 ] = 43

indexValue[ 325 ] = "vCard"
indexStartIndices[ 325 ] = 847
indexStopIndices[ 325 ] = 847
linkNames[ 847 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_IDENTITY"
topicIndices[ 847 ] = 42

indexValue[ 326 ] = "vcards"
indexStartIndices[ 326 ] = 848
indexStopIndices[ 326 ] = 848
linkNames[ 848 ] = "nethelp:netscape/Messengr:ADD_USER_PROPERTIES"
topicIndices[ 848 ] = 60

indexValue[ 327 ] = "viewing attachments"
indexStartIndices[ 327 ] = 849
indexStopIndices[ 327 ] = 849
linkNames[ 849 ] = "nethelp:netscape/Messengr:viewing_attachments"
topicIndices[ 849 ] = 48

indexValue[ 328 ] = "viewing web pages"
indexStartIndices[ 328 ] = 850
indexStopIndices[ 328 ] = 852
linkNames[ 850 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 850 ] = 61
linkNames[ 851 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 851 ] = 31
linkNames[ 852 ] = "nethelp:netscape/Navigatr:nav_histsearch"
topicIndices[ 852 ] = 168

indexValue[ 329 ] = "view source"
indexStartIndices[ 329 ] = 853
indexStopIndices[ 329 ] = 853
linkNames[ 853 ] = "nethelp:netscape/Navigatr:nav_checktec"
topicIndices[ 853 ] = 66

indexValue[ 330 ] = "virtual newsgroup"
indexStartIndices[ 330 ] = 854
indexStopIndices[ 330 ] = 854
linkNames[ 854 ] = "nethelp:netscape/Messengr:SEARCH_MAILNEWS"
topicIndices[ 854 ] = 1

indexValue[ 331 ] = "web pages, attaching to email"
indexStartIndices[ 331 ] = 855
indexStopIndices[ 331 ] = 855
linkNames[ 855 ] = "nethelp:netscape/Messengr:attaching_file"
topicIndices[ 855 ] = 47

indexValue[ 332 ] = "web pages, creating"
indexStartIndices[ 332 ] = 856
indexStopIndices[ 332 ] = 856
linkNames[ 856 ] = "nethelp:netscape/Composer:create_document"
topicIndices[ 856 ] = 4

indexValue[ 333 ] = "web pages, editing"
indexStartIndices[ 333 ] = 857
indexStopIndices[ 333 ] = 858
linkNames[ 857 ] = "nethelp:netscape/Composer:SPELL_CHECK"
topicIndices[ 857 ] = 21
linkNames[ 858 ] = "nethelp:netscape/Composer:EDIT_DICTIONARY"
topicIndices[ 858 ] = 22

indexValue[ 334 ] = "web pages, viewing"
indexStartIndices[ 334 ] = 859
indexStopIndices[ 334 ] = 862
linkNames[ 859 ] = "nethelp:netscape/Composer:browse_new_page"
topicIndices[ 859 ] = 78
linkNames[ 860 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 860 ] = 61
linkNames[ 861 ] = "nethelp:netscape/Navigatr:nav_openpage"
topicIndices[ 861 ] = 31
linkNames[ 862 ] = "nethelp:netscape/Navigatr:nav_histsearch"
topicIndices[ 862 ] = 168

indexValue[ 335 ] = "websites, finding"
indexStartIndices[ 335 ] = 863
indexStopIndices[ 335 ] = 863
linkNames[ 863 ] = "nethelp:netscape/Navigatr:nav_smartbrowse"
topicIndices[ 863 ] = 133

indexValue[ 336 ] = "windows, Messenger"
indexStartIndices[ 336 ] = 864
indexStopIndices[ 336 ] = 864
linkNames[ 864 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_MAIN_PANE"
topicIndices[ 864 ] = 72

indexValue[ 337 ] = "windows, Navigator"
indexStartIndices[ 337 ] = 865
indexStopIndices[ 337 ] = 866
linkNames[ 865 ] = "nethelp:netscape/Navigatr:nav_view"
topicIndices[ 865 ] = 61
linkNames[ 866 ] = "nethelp:netscape/Trouble:trouble_find_nav"
topicIndices[ 866 ] = 121

indexValue[ 338 ] = "window settings"
indexStartIndices[ 338 ] = 867
indexStopIndices[ 338 ] = 867
linkNames[ 867 ] = "nethelp:netscape/Messengr:PREFERENCES_MAILNEWS_WINDOW"
topicIndices[ 867 ] = 46

indexValue[ 339 ] = "wizards"
indexStartIndices[ 339 ] = 868
indexStopIndices[ 339 ] = 868
linkNames[ 868 ] = "nethelp:netscape/Messengr:MAIL_NEWS_WIZARD"
topicIndices[ 868 ] = 167

indexValue[ 340 ] = "working offline"
indexStartIndices[ 340 ] = 869
indexStopIndices[ 340 ] = 876
linkNames[ 869 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DOWNLOAD"
topicIndices[ 869 ] = 104
linkNames[ 870 ] = "nethelp:netscape/News:NEWS_DISCUSSION_DISKSPACE"
topicIndices[ 870 ] = 105
linkNames[ 871 ] = "nethelp:netscape/News:off_work"
topicIndices[ 871 ] = 106
linkNames[ 872 ] = "nethelp:netscape/News:OFFLINE_INTRO"
topicIndices[ 872 ] = 97
linkNames[ 873 ] = "nethelp:netscape/News:MAILNEWS_SYNCHRONIZE"
topicIndices[ 873 ] = 99
linkNames[ 874 ] = "nethelp:netscape/News:MAILNEWS_SELECT_ITEMS"
topicIndices[ 874 ] = 100
linkNames[ 875 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE"
topicIndices[ 875 ] = 101
linkNames[ 876 ] = "nethelp:netscape/News:PREFERENCES_OFFLINE_GROUPS"
topicIndices[ 876 ] = 107

indexValue[ 341 ] = "XBM"
indexStartIndices[ 341 ] = 877
indexStopIndices[ 341 ] = 877
linkNames[ 877 ] = "nethelp:netscape/Navigatr:nav_autoload"
topicIndices[ 877 ] = 58

topicStrings[ 0 ] = "Deleting Messages"
topicStrings[ 1 ] = "Searching Through Messages"
topicStrings[ 2 ] = "Specifying How Long to Track History"
topicStrings[ 3 ] = "Handling Different File Types"
topicStrings[ 4 ] = "Starting From a New Page"
topicStrings[ 5 ] = "Why can't I decrypt a message or page?"
topicStrings[ 6 ] = "Storing Messages and Sending Automatic Copies"
topicStrings[ 7 ] = "Subscribing to Newsgroups and IMAP Folders"
topicStrings[ 8 ] = "Customizing the Toolbars"
topicStrings[ 9 ] = "Adjusting the Component Bar"
topicStrings[ 10 ] = "Changing Colors or Backgrounds"
topicStrings[ 11 ] = "Specifying the Components That Appear at Startup"
topicStrings[ 12 ] = "Specifying the Starting Page"
topicStrings[ 13 ] = "Opening Your Inbox"
topicStrings[ 14 ] = "New Mail Notification"
topicStrings[ 15 ] = "How do I know when I have new mail?"
topicStrings[ 16 ] = "How do I make Netscape start up with a mail window instead of the browser window?"
topicStrings[ 17 ] = "Why can't I get new messages over my Dial-up connection?"
topicStrings[ 18 ] = "Looking Up Addresses Through a Directory Service"
topicStrings[ 19 ] = "Changing Newsgroup Server Properties"
topicStrings[ 20 ] = "Getting the Latest Software Automatically"
topicStrings[ 21 ] = "Checking the Spelling (Windows and Unix only)"
topicStrings[ 22 ] = "About the Edit Dictionary Dialog Box (Windows only)"
topicStrings[ 23 ] = "Formatting a Paragraph"
topicStrings[ 24 ] = "Changing Text Color, Style, and Font"
topicStrings[ 25 ] = "Saving a Page"
topicStrings[ 26 ] = "PowerPlant not installed (Mac OS)"
topicStrings[ 27 ] = "Setting Language Priorities"
topicStrings[ 28 ] = "Linking to Other Pages"
topicStrings[ 29 ] = "About the Link Properties Dialog Box"
topicStrings[ 30 ] = "Composer Preferences -- Publish"
topicStrings[ 31 ] = "Moving to Another Page"
topicStrings[ 32 ] = "Retracing Your Steps"
topicStrings[ 33 ] = "Creating a Bookmark"
topicStrings[ 34 ] = "Creating an Internet Shortcut"
topicStrings[ 35 ] = "Searching the Bookmark List"
topicStrings[ 36 ] = "Checking the Freshness of Your Bookmarks"
topicStrings[ 37 ] = "Copying Part of a Page"
topicStrings[ 38 ] = "How can I clear the Location (Netsite) drop-down list of web sites (Windows only)?"
topicStrings[ 39 ] = "Disk quota exceeded (in Mail)"
topicStrings[ 40 ] = "Can I navigate without using a mouse?"
topicStrings[ 41 ] = "I'm stuck on a page: the Back button isn't working"
topicStrings[ 42 ] = "Setting Your Identity Preferences "
topicStrings[ 43 ] = "Why is Messenger asking for my user name and password?"
topicStrings[ 44 ] = "Addressing a Message"
topicStrings[ 45 ] = "How do I send email without showing a recipient's addresses or name in the header?"
topicStrings[ 46 ] = "Choosing Window Settings in Messenger"
topicStrings[ 47 ] = "Attaching a File, Web Page, or Personal Card"
topicStrings[ 48 ] = "Viewing and Opening Attachments"
topicStrings[ 49 ] = "Saving Attachments"
topicStrings[ 50 ] = "Setting Preferences for Outgoing Messages"
topicStrings[ 51 ] = "Moving Messages to and from the Trash"
topicStrings[ 52 ] = "Forwarding a Message"
topicStrings[ 53 ] = "Why can't I forward a decrypted message?"
topicStrings[ 54 ] = "Specifying Meta Tags"
topicStrings[ 55 ] = "Selecting a Directory for Offline Use"
topicStrings[ 56 ] = "Inserting an Image"
topicStrings[ 57 ] = "About the Images Properties Dialog Box"
topicStrings[ 58 ] = "Automatic Loading"
topicStrings[ 59 ] = "Searching Within a Page"
topicStrings[ 60 ] = "Adding a Name to Your Address Book"
topicStrings[ 61 ] = "Viewing a Page"
topicStrings[ 62 ] = "Choosing a Password to Protect Your Certificates"
topicStrings[ 63 ] = "I forgot my password (somone else set my password)"
topicStrings[ 64 ] = "Inserting Raw HTML"
topicStrings[ 65 ] = "About the Extra HTML Tag Dialog Box"
topicStrings[ 66 ] = "Viewing a Page's Source Code"
topicStrings[ 67 ] = "What do I do when I see a Java download alert?"
topicStrings[ 68 ] = "Changing Cache Settings"
topicStrings[ 69 ] = "How do I clear the disk cache?"
topicStrings[ 70 ] = "Linking Within the Same Page"
topicStrings[ 71 ] = "Linking to Images"
topicStrings[ 72 ] = "Setting General Mail and Newsgroup Preferences"
topicStrings[ 73 ] = "Posting Newsgroup Messages"
topicStrings[ 74 ] = "Contributing to Ongoing Discussions"
topicStrings[ 75 ] = "Setting Advanced IMAP Server Properties"
topicStrings[ 76 ] = "Setting Up Roaming Access"
topicStrings[ 77 ] = "Too much network traffic"
topicStrings[ 78 ] = "Saving and Browsing Your New Page"
topicStrings[ 79 ] = "Saving and Re-using a Message Draft"
topicStrings[ 80 ] = "Creating Message Filters"
topicStrings[ 81 ] = "Specifying Settings for Message Filters"
topicStrings[ 82 ] = "Choosing Between IMAP and POP3 Mail Servers"
topicStrings[ 83 ] = "Confirming That Your Message Was Received"
topicStrings[ 84 ] = "Reading Newsgroup Messages"
topicStrings[ 85 ] = "Updating Newsgroups"
topicStrings[ 86 ] = "Server does not have a DNS entry"
topicStrings[ 87 ] = "Connection reset by peer"
topicStrings[ 88 ] = "Not implemented"
topicStrings[ 89 ] = "Server error"
topicStrings[ 90 ] = "404 Access denied"
topicStrings[ 91 ] = "Can't read newsgroups"
topicStrings[ 92 ] = "Unknown error in Address book (Mac OS)"
topicStrings[ 93 ] = "Why can't I encrypt a message or add my digital signature?"
topicStrings[ 94 ] = "About the Alternate Image Properties Dialog Box (Windows only)"
topicStrings[ 95 ] = "About the Image Conversion Dialog Box (Windows only)"
topicStrings[ 96 ] = "Handling Cookies"
topicStrings[ 97 ] = "Preparing to Work Offline"
topicStrings[ 98 ] = "Downloading Items for Working Offline"
topicStrings[ 99 ] = "Updating the Items You Selected for Downloading"
topicStrings[ 100 ] = "Selecting Items for Download"
topicStrings[ 101 ] = "Setting Offline Preferences"
topicStrings[ 102 ] = "Changing a Table "
topicStrings[ 103 ] = "Using the Table Properties Dialog Box"
topicStrings[ 104 ] = "Setting Download Options for Newsgroups"
topicStrings[ 105 ] = "Setting Disk Space Properties for Newsgroups"
topicStrings[ 106 ] = "Going Offline to Work"
topicStrings[ 107 ] = "Downloading Newsgroups for Offline Reading"
topicStrings[ 108 ] = "Moving, Copying, and Deleting Tables"
topicStrings[ 109 ] = "Removing a Newsgroup"
topicStrings[ 110 ] = "Inserting Horizontal Lines"
topicStrings[ 111 ] = "Creating a Mailing List"
topicStrings[ 112 ] = "Identifying Your Newsgroup Servers"
topicStrings[ 113 ] = "Adding a Newsgroup Server"
topicStrings[ 114 ] = "Why can't I read newsgroups?"
topicStrings[ 115 ] = "Newsgroup Troubles"
topicStrings[ 116 ] = "Viewing and Changing Newsgroup Properties"
topicStrings[ 117 ] = "Sorting and Threading Messages"
topicStrings[ 118 ] = "Sending Signed and Encrypted Messages"
topicStrings[ 119 ] = "Viewing, Editing, Verifying, and Deleting Certificates and Signers"
topicStrings[ 120 ] = "Setting Security Preferences for Browsing"
topicStrings[ 121 ] = "I can't find the Navigator window"
topicStrings[ 122 ] = "Adding Contact Information to An Address Card"
topicStrings[ 123 ] = "Setting Message Formatting Preferences"
topicStrings[ 124 ] = "Setting Page Colors and Backgrounds"
topicStrings[ 125 ] = "Composer Preferences -- General"
topicStrings[ 126 ] = "Inserting a Table"
topicStrings[ 127 ] = "Viewing and Editing Security Modules"
topicStrings[ 128 ] = "How can I disable AOL Instant Messenger?"
topicStrings[ 129 ] = "Setting Page Location, Title, and Author"
topicStrings[ 130 ] = "Setting Up Your Mail Servers"
topicStrings[ 131 ] = "Setting IMAP Mail Server Properties"
topicStrings[ 132 ] = "Controlling Access of Java Applets and JavaScripts"
topicStrings[ 133 ] = "Finding the Pages You Want (Smart Browsing)"
topicStrings[ 134 ] = "Saving and Printing Messages"
topicStrings[ 135 ] = "Creating a Folder"
topicStrings[ 136 ] = "Renaming a Folder"
topicStrings[ 137 ] = "Filing Messages"
topicStrings[ 138 ] = "Setting Folder Properties"
topicStrings[ 139 ] = "Using the Folder Properties Download Options Panel"
topicStrings[ 140 ] = "Managing Your Disk Space Preferences"
topicStrings[ 141 ] = "Putting Your Page on the Web"
topicStrings[ 142 ] = "Setting General Mail Server Properties"
topicStrings[ 143 ] = "Upgrading IMAP from Communicator 4.0 to 4.5"
topicStrings[ 144 ] = "Installing Plug-Ins"
topicStrings[ 145 ] = "Setting Security Preferences for Sending Messages"
topicStrings[ 146 ] = "Getting Security Certificates"
topicStrings[ 147 ] = "Searching for a Newsgroup"
topicStrings[ 148 ] = "Listing New Newsgroups"
topicStrings[ 149 ] = "Creating an Address Book"
topicStrings[ 150 ] = "Using the Message Composition Window"
topicStrings[ 151 ] = "Creating or Using a Message Template"
topicStrings[ 152 ] = "Setting Addressing Preferences"
topicStrings[ 153 ] = "Choosing How You View the Messenger Window"
topicStrings[ 154 ] = "Adding and Removing Message Headers"
topicStrings[ 155 ] = "Changing Fonts"
topicStrings[ 156 ] = "Adding Notes to an Address Card"
topicStrings[ 157 ] = "Adding Netscape Conference Information"
topicStrings[ 158 ] = "Setting Proxy Values"
topicStrings[ 159 ] = "Specifying Where Your Roaming Profile Is Located"
topicStrings[ 160 ] = "Specifying Files to Be Transferred at Startup and Shutdown"
topicStrings[ 161 ] = "Composing Mail and Newsgroup Messages"
topicStrings[ 162 ] = "Replying to a Message"
topicStrings[ 163 ] = "Using the HTML Mail Question Dialog Box"
topicStrings[ 164 ] = "Using Your Palm Pilot with Messenger (Windows Only)"
topicStrings[ 165 ] = "Searching an Address Book"
topicStrings[ 166 ] = "Specifying Where to Search for Messages"
topicStrings[ 167 ] = "Using the Mail & Newsgroups Setup Program"
topicStrings[ 168 ] = "Retracing Your Steps in Detail: The History List"
topicStrings[ 169 ] = "Viewing Information in the Security Window"
topicStrings[ 170 ] = "Viewing a Page's Information"
topicStrings[ 171 ] = "Adding and Deleting Rows, Columns, and Cells"
topicStrings[ 172 ] = "Setting POP3 Mail Server Properties"
topicStrings[ 173 ] = "How do I convert from a different mail system (like Eudora or Outlook Express) to Netscape Messenger?"
topicStrings[ 174 ] = "Organizing Your Bookmarks"
topicStrings[ 175 ] = "Importing Address Books and Mail Messages"
topicStrings[ 176 ] = "Keeping Multiple Bookmark Lists"
topicStrings[ 177 ] = "Why can't I alphabetize my bookmarks?"
topicStrings[ 178 ] = "Selecting Addresses"
topicStrings[ 179 ] = "Adding or Updating Directory Servers"
topicStrings[ 180 ] = "Exporting an Address Book"
topicStrings[ 181 ] = "Why do I see the Mail & Newsgroups set-up screen when I open my Inbox or click Get Msg?"
topicStrings[ 182 ] = "What does Possible Message Tampering mean?"
topicStrings[ 183 ] = "Printing a Page"

var lastKnownValue = ""
var startIndex
var stopIndex

function SetGlobals( start, stop )
{
startIndex = start
stopIndex = stop
}

