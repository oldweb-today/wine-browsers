// Netscape User Preferences
// This is a generated file!  Do not edit.

user_pref("browser.goBrowsing.enabled", false);
user_pref("browser.related.enabled", false);
user_pref("browser.startup.homepage_override", false);
user_pref("browser.url_history.URL_1", "http://example.com/");
user_pref("browser.url_history.URL_2", "http://netcapsule_pywb_1:8080/");
user_pref("browser.window_rect", "0,0,632,480");
user_pref("custtoolbar.personal_toolbar_folder", "Personal Toolbar Folder");
user_pref("editor.author", "OldWeb");
user_pref("ldap_2.servers.netcenter.csid", "UTF-8");
user_pref("ldap_2.servers.netcenter.filename", "netcenter.na2");
user_pref("ldap_2.servers.netcenter.replication.lastChangeNumber", 0);
user_pref("ldap_2.servers.pab.csid", "iso-8859-1");
user_pref("ldap_2.servers.pab.filename", "pab.na2");
user_pref("ldap_2.servers.pab.replication.lastChangeNumber", 0);
user_pref("ldap_2.servers.verisign.csid", "UTF-8");
user_pref("ldap_2.servers.verisign.filename", "verisign.na2");
user_pref("ldap_2.servers.verisign.position", 3);
user_pref("ldap_2.servers.verisign.replication.lastChangeNumber", 0);
user_pref("ldap_2.version", 2);
user_pref("mail.identity.username", "OldWeb");
user_pref("mail.pop_name", "mail");
user_pref("mail.smtp_name", "mail");
user_pref("mailnews.profile_age", 13);
user_pref("network.proxy.http", "netcapsule_pywb_1");
user_pref("network.proxy.http_port", 8080);
user_pref("network.proxy.ssl", "netcapsule_pywb_1");
user_pref("network.proxy.ssl_port", 8080);
user_pref("network.proxy.type", 1);
user_pref("taskbar.floating", false);
user_pref("taskbar.x", 634);
user_pref("taskbar.y", 5);
