// Netscape User Preferences
// This is a generated file!  Do not edit.

user_pref("browser.startup.homepage_override", false);
user_pref("browser.window_rect", "0,0,1423,768");
user_pref("custtoolbar.personal_toolbar_folder", "Personal Toolbar Folder");
user_pref("editor.author", "WebRecorder");
user_pref("ldap_2.servers.netcenter.csid", "UTF-8");
user_pref("ldap_2.servers.netcenter.filename", "netcenter.na2");
user_pref("ldap_2.servers.netcenter.replication.lastChangeNumber", 0);
user_pref("ldap_2.servers.pab.csid", "iso-8859-1");
user_pref("ldap_2.servers.pab.filename", "pab.na2");
user_pref("ldap_2.servers.pab.replication.lastChangeNumber", 0);
user_pref("ldap_2.servers.verisign.csid", "UTF-8");
user_pref("ldap_2.servers.verisign.filename", "verisign.na2");
user_pref("ldap_2.servers.verisign.position", 3);
user_pref("ldap_2.servers.verisign.replication.lastChangeNumber", 0);
user_pref("ldap_2.version", 2);
user_pref("mail.identity.useremail", "webrecorder@rhizome.org");
user_pref("mail.identity.username", "WebRecorder");
user_pref("mail.pop_name", "default");
user_pref("mail.smtp_name", "default");
user_pref("mailnews.profile_age", 13);
user_pref("taskbar.floating", false);
user_pref("taskbar.x", 634);
user_pref("taskbar.y", 5);
